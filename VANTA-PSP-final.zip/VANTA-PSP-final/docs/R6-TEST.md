# VANTA R6 test

1. Confirme Biblioteca, Performance, Saves e controles.
2. Abra Visual e teste resolução, anisotrópico, filtro de textura, upscale e pós-processamento.
3. Dentro do jogo, Voltar: o VANTA Quick Tune deve abrir compacto com Desempenho, Visual e Saves.
4. Expanda só uma seção por vez.
5. Teste Sharpen e FSR-RCAS, depois volte para Off.
6. Confirme que Save State e Memory Card continuam funcionando.
7. Em jogos pesados, mantenha Upscale de texturas Off se houver perda de FPS.
