# VANTA R5 test

1. Abra Saves: deve aparecer STATUS • PRONTO PARA GRAVAR.
2. Abra um jogo e faça um save normal pelo próprio jogo.
3. Feche e reabra o jogo; confirme que o save normal reaparece.
4. Durante o jogo: Voltar > VANTA SAVE HUB > Slot 1 > Salvar estado agora.
5. Mude de cena e carregue o Slot 1.
6. A área Saves deve contar saves do jogo e Save States.
