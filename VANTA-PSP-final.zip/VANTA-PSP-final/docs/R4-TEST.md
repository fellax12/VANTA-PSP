# VANTA R4 — teste rápido

1. Abra Performance e confirme que Renderizador/Resolução/Frame skip abrem uma lista de opções.
2. Abra um jogo e pressione Voltar.
3. Em VANTA QUICK TUNE, abra Perfil/Resolução/Frame skip e selecione pelo submenu.
4. Em VANTA SAVE HUB, selecione Slot 1 e pressione Salvar estado agora.
5. Volte ao jogo, avance alguns segundos, abra o menu e carregue Slot 1.
6. Abra Memory Card • Gerenciar savedata para conferir saves normais do PSP.
