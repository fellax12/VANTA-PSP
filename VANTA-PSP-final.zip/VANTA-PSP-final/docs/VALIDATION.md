# Validation gates

The build workflow should:
1. verify the package structure;
2. syntax-check apply_vanta.py;
3. clone PPSSPP v1.20.4;
4. apply patch anchors fail-fast;
5. verify VANTA Java/JNI symbols;
6. build normalOptimized ARM64;
7. locate APK, hash it, and upload the artifact.
