# VANTA R3 test checklist

1. Home: no overlapping cards/buttons in landscape.
2. Library: 2 columns on compact screens, 3 on wider screens.
3. Heavy game: start Dante's Inferno or similar.
4. In game, press Back/Pause and open VANTA Quick Tune.
5. Cycle profile to Turbo.
6. Verify resolution cycles 1x-4x and frame skip cycles Off-3.
7. Resume game and compare stutter/FPS.
8. Verify returning to VANTA still works.
