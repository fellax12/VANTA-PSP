# VANTA PSP — Unified Release Candidate

VANTA is an Android-first PSP emulation shell built on PPSSPP 1.20.4.

Included:
- VANTA as the launcher and normal user-facing flow;
- library folder scan, search, recents and favorites;
- VANTA performance profiles and custom tuning;
- selected VANTA settings applied to the native core before graphics startup;
- controller detection and live input diagnostics;
- PPSSPP graphics/settings screens removed from the normal pause-flow where VANTA replaces them;
- ARM64 optimized build;
- PPSSPP attribution and GPL notice preserved.

The core keeps PPSSPP's own safe CPU/JIT capability detection instead of forcing JIT on devices that cannot use it.

No games, firmware, BIOS files or copyrighted game data are included.

This package is a release candidate: static checks are performed before delivery, and the GitHub Actions Android compile + real-device game test are the final acceptance gates.
