# VANTA PSP R4 Fix 1

# VANTA PSP — Unified R3

VANTA is an Android-first PSP emulation shell built on PPSSPP 1.20.4.

Included:
- VANTA as the launcher and normal user-facing flow;
- library folder scan, search, recents and favorites;
- VANTA performance profiles and custom tuning;
- selected VANTA settings applied to the native core before graphics startup;
- controller detection and live input diagnostics;
- PPSSPP graphics/settings screens removed from the normal pause-flow where VANTA replaces them;
- ARM64 optimized build;
- PPSSPP attribution and GPL notice preserved.

The core keeps PPSSPP's own safe CPU/JIT capability detection instead of forcing JIT on devices that cannot use it.

No games, firmware, BIOS files or copyrighted game data are included.

This package is a release candidate: static checks are performed before delivery, and the GitHub Actions Android compile + real-device game test are the final acceptance gates.


## R3
- home responsiva para celulares em landscape;
- sidebar menor e alinhamento de botões/cards corrigido;
- biblioteca dinâmica em 2/3 colunas;
- presets de performance em faixa horizontal;
- VANTA Quick Tune dentro do menu de pausa;
- troca em jogo de perfil, resolução interna, frameskip, auto frameskip e hardware transform;
- Turbo reajustado para jogos PSP pesados.


## R4 — Save Center + submenus
- Configurações enumeradas abrem submenus de escolha em vez de circular a cada toque.
- VANTA Quick Tune usa PopupMultiChoice para perfil, resolução, frameskip e slot de estado.
- VANTA SAVE HUB dentro do jogo: 5 slots, salvar estado, carregar estado e gerenciador de Memory Card/savedata.
- Nova área Saves no launcher explica e centraliza Memory Card vs Save State.
