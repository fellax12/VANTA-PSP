#!/usr/bin/env python3
from __future__ import annotations
import shutil
import sys
from pathlib import Path

APP_ID = "com.vantapsp.emulator"
APP_NAME = "VANTA PSP"

def fail(message: str) -> None:
    raise SystemExit(f"VANTA patch error: {message}")

def replace_required(text: str, old: str, new: str, *, count: int = 1, label: str = "patch") -> str:
    hits = text.count(old)
    if hits < count:
        fail(f"upstream changed; {label}: expected >= {count}, found {hits}")
    return text.replace(old, new, count)

def patch_gradle(root: Path) -> None:
    path = root / "android" / "build.gradle.kts"
    text = path.read_text(encoding="utf-8")
    if 'applicationId = "org.ppsspp.ppsspp"' not in text:
        fail("Android applicationId anchor missing")
    text = text.replace('applicationId = "org.ppsspp.ppsspp"', f'applicationId = "{APP_ID}"')
    text = replace_required(text,
        'abiFilters.addAll(listOf("armeabi-v7a", "arm64-v8a", "x86_64"))',
        'abiFilters.add("arm64-v8a")',
        label="normal ARM64 ABI filter")
    old = '''create("optimized") {
\t\t\tisMinifyEnabled = false
\t\t\tisJniDebuggable = true
\t\t\tsigningConfig = signingConfigs.getByName("debug")
\t\t}'''
    new = '''create("optimized") {
\t\t\tisMinifyEnabled = false
\t\t\tisJniDebuggable = false
\t\t\tsigningConfig = signingConfigs.getByName("debug")
\t\t}'''
    text = replace_required(text, old, new, label="optimized build type")
    path.write_text(text, encoding="utf-8")

def patch_strings(root: Path) -> None:
    path = root / "android" / "res" / "values" / "strings.xml"
    text = path.read_text(encoding="utf-8")
    text = replace_required(text, '<string name="app_name">PPSSPP</string>',
        f'<string name="app_name">{APP_NAME}</string>', label="app name")
    text = replace_required(text, '<string name="shortcut_name">PPSSPP game</string>',
        '<string name="shortcut_name">VANTA game</string>', label="shortcut name")
    path.write_text(text, encoding="utf-8")

def patch_manifest(root: Path) -> None:
    path = root / "android" / "AndroidManifest.xml"
    text = path.read_text(encoding="utf-8")
    launcher = '''            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
'''
    text = replace_required(text, launcher, "", label="PPSSPP launcher filter")
    marker = '''        <activity
            android:name=".PpssppActivity"'''
    insert = '''        <activity
            android:name=".VantaActivity"
            android:configChanges="locale|keyboard|keyboardHidden|navigation|orientation|screenSize|uiMode"
            android:screenOrientation="sensorLandscape"
            android:theme="@style/ppsspp_style"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".PpssppActivity"'''
    text = replace_required(text, marker, insert, label="VANTA launcher activity")
    path.write_text(text, encoding="utf-8")

def patch_nativeapp_java(root: Path) -> None:
    path = root / "android" / "src" / "org" / "ppsspp" / "ppsspp" / "NativeApp.java"
    text = path.read_text(encoding="utf-8")
    anchor = '\tpublic static native String queryConfig(String queryName);'
    addition = '''\tpublic static native void vantaSetBootConfig(int backend, int resolution, int frameSkip,
\t\tboolean autoFrameSkip, boolean fastMemory, boolean hardwareTransform, boolean sustainedPerformance,
\t\tint anisotropy, int textureFiltering, boolean smart2DFiltering, int textureScaleLevel,
\t\tint textureScaleType, boolean deposterize, int postShader);
\tpublic static native String queryConfig(String queryName);'''
    text = replace_required(text, anchor, addition, label="NativeApp VANTA JNI declaration")
    path.write_text(text, encoding="utf-8")

def patch_activity(root: Path) -> None:
    path = root / "android" / "src" / "org" / "ppsspp" / "ppsspp" / "PpssppActivity.java"
    text = path.read_text(encoding="utf-8")
    anchor = '''\t\tNativeApp.audioConfig(optimalFramesPerBuffer, optimalSampleRate);
\t\tNativeApp.init(model, deviceType, languageRegion, apkFilePath, dataDir, extStorageDir, externalFilesDir, nativeLibDir, additionalStorageDirs, cacheDir, shortcut, installerName, Build.VERSION.SDK_INT, Build.BOARD);'''
    replacement = '''\t\tIntent vantaIntent = getIntent();
\t\tif (vantaIntent != null && vantaIntent.getBooleanExtra("vanta_managed", false)) {
\t\t\tNativeApp.vantaSetBootConfig(
\t\t\t\tvantaIntent.getIntExtra("vanta_backend", 3),
\t\t\t\tvantaIntent.getIntExtra("vanta_resolution", 2),
\t\t\t\tvantaIntent.getIntExtra("vanta_frameskip", 0),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_auto_frameskip", false),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_fast_memory", true),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_hardware_transform", true),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_sustained_performance", false),
\t\t\t\tvantaIntent.getIntExtra("vanta_anisotropy", 4),
\t\t\t\tvantaIntent.getIntExtra("vanta_texture_filtering", 1),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_smart_2d_filtering", false),
\t\t\t\tvantaIntent.getIntExtra("vanta_texture_scale_level", 1),
\t\t\t\tvantaIntent.getIntExtra("vanta_texture_scale_type", 0),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_deposterize", false),
\t\t\t\tvantaIntent.getIntExtra("vanta_post_shader", 0)
\t\t\t);
\t\t}

\t\tNativeApp.audioConfig(optimalFramesPerBuffer, optimalSampleRate);
\t\tNativeApp.init(model, deviceType, languageRegion, apkFilePath, dataDir, extStorageDir, externalFilesDir, nativeLibDir, additionalStorageDirs, cacheDir, shortcut, installerName, Build.VERSION.SDK_INT, Build.BOARD);'''
    text = replace_required(text, anchor, replacement, label="PpssppActivity VANTA boot config")
    path.write_text(text, encoding="utf-8")

def patch_native_cpp(root: Path) -> None:
    path = root / "android" / "jni" / "app-android.cpp"
    text = path.read_text(encoding="utf-8")
    include_anchor = "#include <cstdlib>\n#include <cstdint>"
    include_replacement = "#include <algorithm>\n#include <cstdlib>\n#include <cstdint>"
    text = replace_required(text, include_anchor, include_replacement, label="C++ algorithm include")
    anchor = '''extern "C" void Java_org_ppsspp_ppsspp_NativeApp_audioConfig
\t(JNIEnv *env, jclass, jint optimalFPB, jint optimalSR) {
\toptimalFramesPerBuffer = optimalFPB;
\toptimalSampleRate = optimalSR;
}'''
    addition = anchor + r'''

struct VantaBootConfig {
	bool pending = false;
	int backend = 3;
	int resolution = 2;
	int frameSkip = 0;
	bool autoFrameSkip = false;
	bool fastMemory = true;
	bool hardwareTransform = true;
	bool sustainedPerformance = false;
	int anisotropy = 4;
	int textureFiltering = 1;
	bool smart2DFiltering = false;
	int textureScaleLevel = 1;
	int textureScaleType = 0;
	bool deposterize = false;
	int postShader = 0;
};

static VantaBootConfig g_vantaBootConfig;

extern "C" void Java_org_ppsspp_ppsspp_NativeApp_vantaSetBootConfig(
	JNIEnv *, jclass, jint backend, jint resolution, jint frameSkip,
	jboolean autoFrameSkip, jboolean fastMemory, jboolean hardwareTransform, jboolean sustainedPerformance,
	jint anisotropy, jint textureFiltering, jboolean smart2DFiltering, jint textureScaleLevel,
	jint textureScaleType, jboolean deposterize, jint postShader) {
	g_vantaBootConfig.pending = true;
	g_vantaBootConfig.backend = backend;
	g_vantaBootConfig.resolution = resolution;
	g_vantaBootConfig.frameSkip = frameSkip;
	g_vantaBootConfig.autoFrameSkip = autoFrameSkip;
	g_vantaBootConfig.fastMemory = fastMemory;
	g_vantaBootConfig.hardwareTransform = hardwareTransform;
	g_vantaBootConfig.sustainedPerformance = sustainedPerformance;
	g_vantaBootConfig.anisotropy = anisotropy;
	g_vantaBootConfig.textureFiltering = textureFiltering;
	g_vantaBootConfig.smart2DFiltering = smart2DFiltering;
	g_vantaBootConfig.textureScaleLevel = textureScaleLevel;
	g_vantaBootConfig.textureScaleType = textureScaleType;
	g_vantaBootConfig.deposterize = deposterize;
	g_vantaBootConfig.postShader = postShader;
}'''
    text = replace_required(text, anchor, addition, label="VANTA boot config JNI")
    init_anchor = '''\tNativeInit((int)args.size(), &args[0], user_data_path.c_str(), externalStorageDir.c_str(), cacheDir.c_str());

\tbFirstResume = true;'''
    init_replace = '''\tNativeInit((int)args.size(), &args[0], user_data_path.c_str(), externalStorageDir.c_str(), cacheDir.c_str());

	if (g_vantaBootConfig.pending) {
		int backend = g_vantaBootConfig.backend;
		if (backend != (int)GPUBackend::OPENGL && backend != (int)GPUBackend::VULKAN)
			backend = (int)GPUBackend::VULKAN;

		g_Config.iGPUBackend = backend;
		SetGPUBackend((GPUBackend)backend);
		g_Config.iInternalResolution = std::clamp(g_vantaBootConfig.resolution, 1, 4);
		g_Config.iFrameSkip = std::clamp(g_vantaBootConfig.frameSkip, 0, 3);
		g_Config.bAutoFrameSkip = g_vantaBootConfig.autoFrameSkip;
		g_Config.bFastMemory = g_vantaBootConfig.fastMemory;
		g_Config.bHardwareTransform = g_vantaBootConfig.hardwareTransform;
		g_Config.bSustainedPerformanceMode = g_vantaBootConfig.sustainedPerformance;
		g_Config.iAnisotropyLevel = std::clamp(g_vantaBootConfig.anisotropy, 0, 4);
		g_Config.iTexFiltering = std::clamp(g_vantaBootConfig.textureFiltering, 1, 4);
		g_Config.bSmart2DTexFiltering = g_vantaBootConfig.smart2DFiltering;
		g_Config.iTexScalingLevel = std::clamp(g_vantaBootConfig.textureScaleLevel, 1, 3);
		g_Config.iTexScalingType = std::clamp(g_vantaBootConfig.textureScaleType, 0, 3);
		g_Config.bTexDeposterize = g_vantaBootConfig.deposterize;
		g_Config.vPostShaderNames.clear();
		switch (std::clamp(g_vantaBootConfig.postShader, 0, 6)) {
		case 1: g_Config.vPostShaderNames.push_back("Sharpen"); break;
		case 2: g_Config.vPostShaderNames.push_back("FXAA"); break;
		case 3: g_Config.vPostShaderNames.push_back("Natural"); break;
		case 4: g_Config.vPostShaderNames.push_back("PSPColor"); break;
		case 5: g_Config.vPostShaderNames.push_back("FSR-RCAS"); break;
		case 6: g_Config.vPostShaderNames.push_back("Bloom"); break;
		default: break;
		}
		g_Config.bShaderChainRequires60FPS = false;
		g_Config.bPauseMenuExitsEmulator = true;

		INFO_LOG(Log::System,
			"VANTA profile: backend=%d resolution=%d frameskip=%d auto=%d fastmem=%d hwtransform=%d sustained=%d aniso=%d texfilter=%d texscale=%d post=%d",
			g_Config.iGPUBackend, g_Config.iInternalResolution, g_Config.iFrameSkip,
			(int)g_Config.bAutoFrameSkip, (int)g_Config.bFastMemory,
			(int)g_Config.bHardwareTransform, (int)g_Config.bSustainedPerformanceMode,
			g_Config.iAnisotropyLevel, g_Config.iTexFiltering, g_Config.iTexScalingLevel, g_vantaBootConfig.postShader);

		g_vantaBootConfig.pending = false;
	}

	bFirstResume = true;'''
    text = replace_required(text, init_anchor, init_replace, label="VANTA runtime profile application")
    if r"\tNativeInit" in text:
        fail("escaped tab leaked into C++ source")
    path.write_text(text, encoding="utf-8")


def patch_vanta_storage(root: Path) -> None:
    path = root / "UI" / "NativeApp.cpp"
    text = path.read_text(encoding="utf-8")

    anchor = """\t} else {
\t\tINFO_LOG(Log::System, "No memstick directory file found (tried to open '%s')", memstickDirFile.c_str());
\t}

\t// Attempt to create directories after reading the path.
\tif (!System_GetPropertyBool(SYSPROP_ANDROID_SCOPED_STORAGE)) {
\t\tCreateSysDirectories();
\t}"""

    replacement = """\t} else {
\t\tINFO_LOG(Log::System, "No memstick directory file found (tried to open '%s')", memstickDirFile.c_str());
\t}

\t// VANTA: Android scoped storage normally requires a first-run Memory Stick setup.
\t// VANTA boots straight into games, so validate the current Memory Stick and
\t// fall back to PPSSPP's writable app-specific external files directory.
\tif (System_GetPropertyBool(SYSPROP_ANDROID_SCOPED_STORAGE)) {
\t\tbool currentMemStickWritable = false;
\t\tif (!g_Config.memStickDirectory.empty()) {
\t\t\tPath currentWriteTest = g_Config.memStickDirectory / ".vanta_memstick_write_test";
\t\t\tif (File::WriteDataToFile(true, "1", 1, currentWriteTest)) {
\t\t\t\tFile::Delete(currentWriteTest);
\t\t\t\tcurrentMemStickWritable = true;
\t\t\t}
\t\t}

\t\tif (!currentMemStickWritable) {
\t\t\tPath vantaMemStick = !g_extFilesDir.empty() ? Path(g_extFilesDir) : g_Config.internalDataDirectory;
\t\t\tif (!vantaMemStick.empty()) {
\t\t\t\tif (!File::Exists(vantaMemStick)) {
\t\t\t\t\tFile::CreateFullPath(vantaMemStick);
\t\t\t\t}

\t\t\t\tPath writeTest = vantaMemStick / ".vanta_memstick_write_test";
\t\t\t\tif (File::WriteDataToFile(true, "1", 1, writeTest)) {
\t\t\t\t\tFile::Delete(writeTest);
\t\t\t\t\tg_Config.memStickDirectory = vantaMemStick;
\t\t\t\t\tg_Config.defaultCurrentDirectory = vantaMemStick;

\t\t\t\t\tstd::string persisted = vantaMemStick.ToString();
\t\t\t\t\tif (!File::WriteDataToFile(true, persisted.c_str(), persisted.size(), memstickDirFile)) {
\t\t\t\t\t\tWARN_LOG(Log::System, "VANTA: could not persist Memory Stick path to '%s'", memstickDirFile.c_str());
\t\t\t\t\t}

\t\t\t\t\tINFO_LOG(Log::System, "VANTA Memory Stick initialized at '%s'", g_Config.memStickDirectory.c_str());
\t\t\t\t} else {
\t\t\t\t\tERROR_LOG(Log::System, "VANTA: fallback Memory Stick is not writable: '%s'", vantaMemStick.c_str());
\t\t\t\t}
\t\t\t}
\t\t}
\t}

\t// Ensure PSP/SAVEDATA, PSP/PPSSPP_STATE, PSP/SYSTEM, etc. exist.
\tif (!g_Config.memStickDirectory.empty()) {
\t\tif (!CreateSysDirectories()) {
\t\t\tERROR_LOG(Log::System, "VANTA: failed to create Memory Stick directories at '%s'", g_Config.memStickDirectory.c_str());
\t\t}
\t}"""

    text = replace_required(text, anchor, replacement, label="VANTA writable Memory Stick")
    path.write_text(text, encoding="utf-8")

def patch_pause_screen(root: Path) -> None:
    path = root / "UI" / "PauseScreen.cpp"
    text = path.read_text(encoding="utf-8")

    include_anchor = '#include "UI/GameSettingsScreen.h"\n#include "UI/ReportScreen.h"'
    include_replacement = '#include "UI/GameSettingsScreen.h"\n#include "UI/SavedataScreen.h"\n#include "UI/ReportScreen.h"'
    text = replace_required(text, include_anchor, include_replacement, label="SavedataScreen include")

    start = text.find('\tif (g_paramSFO.IsValid() && g_Config.HasGameConfig(g_paramSFO.GetDiscID())) {')
    end_marker = '\n\tif (g_Config.bAchievementsEnable && Achievements::HasAchievementsOrLeaderboards()) {'
    end = text.find(end_marker, start)
    if start == -1 or end == -1:
        fail("PauseScreen settings block anchors missing")

    quick_tune = '''	// VANTA: native quick-tune menu replaces the generic PPSSPP settings entry.
	// VANTA: compact in-game control center. Only one section expands at a time.
	// VANTA R6: Performance + Visual Lab + Save Hub, preserving R5 storage behavior.
	rightColumnItems->Add(new ItemHeader("VANTA QUICK TUNE • CONTROL CENTER"));
	static int vantaPanel = 0;

	Choice *vantaPerformancePanel = rightColumnItems->Add(new Choice(StringFromFormat("Desempenho  %s", vantaPanel == 1 ? "▲" : "▼"), ImageID("I_GEAR")));
	vantaPerformancePanel->OnClick.Add([this](UI::EventParams &) { vantaPanel = vantaPanel == 1 ? 0 : 1; RecreateViews(); });
	Choice *vantaVisualPanel = rightColumnItems->Add(new Choice(StringFromFormat("Visual  %s", vantaPanel == 2 ? "▲" : "▼"), ImageID("I_DISPLAY")));
	vantaVisualPanel->OnClick.Add([this](UI::EventParams &) { vantaPanel = vantaPanel == 2 ? 0 : 2; RecreateViews(); });
	Choice *vantaSavePanel = rightColumnItems->Add(new Choice(StringFromFormat("Saves • Slot %d  %s", g_Config.iCurrentStateSlot + 1, vantaPanel == 3 ? "▲" : "▼"), ImageID("I_FOLDER")));
	vantaSavePanel->OnClick.Add([this](UI::EventParams &) { vantaPanel = vantaPanel == 3 ? 0 : 3; RecreateViews(); });

	if (vantaPanel == 1) {
		rightColumnItems->Add(new ItemHeader("DESEMPENHO"));
		static int vantaProfileChoice = 0;
		if (g_Config.iInternalResolution == 1 && g_Config.iFrameSkip == 1 && g_Config.bAutoFrameSkip) vantaProfileChoice = 1;
		else if (g_Config.iInternalResolution >= 3 && g_Config.iFrameSkip == 0 && !g_Config.bAutoFrameSkip) vantaProfileChoice = 2;
		else if (g_Config.iInternalResolution == 1 && g_Config.iFrameSkip == 0 && !g_Config.bAutoFrameSkip && g_Config.bSustainedPerformanceMode) vantaProfileChoice = 3;
		else vantaProfileChoice = 0;
		static const char *vantaProfiles[] = { "Balanced", "Turbo", "Quality", "Battery" };
		PopupMultiChoice *vantaProfile = rightColumnItems->Add(new PopupMultiChoice(&vantaProfileChoice, "Perfil VANTA", vantaProfiles, 0, ARRAY_SIZE(vantaProfiles), I18NCat::GRAPHICS, screenManager()));
		vantaProfile->OnChoice.Add([this](UI::EventParams &) {
			switch (vantaProfileChoice) {
			case 1: g_Config.iInternalResolution = 1; g_Config.iFrameSkip = 1; g_Config.bAutoFrameSkip = true; g_Config.bSustainedPerformanceMode = false; break;
			case 2: g_Config.iInternalResolution = 3; g_Config.iFrameSkip = 0; g_Config.bAutoFrameSkip = false; g_Config.bSustainedPerformanceMode = false; break;
			case 3: g_Config.iInternalResolution = 1; g_Config.iFrameSkip = 0; g_Config.bAutoFrameSkip = false; g_Config.bSustainedPerformanceMode = true; break;
			default: g_Config.iInternalResolution = 2; g_Config.iFrameSkip = 0; g_Config.bAutoFrameSkip = false; g_Config.bSustainedPerformanceMode = false; break;
			}
			g_Config.bFastMemory = true;
			g_Config.bHardwareTransform = true;
			g_Config.UpdateAfterSettingAutoFrameSkip();
			System_PostUIMessage(UIMessage::GPU_RENDER_RESIZED);
			System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED);
			System_Notify(SystemNotification::SUSTAINED_PERF_CHANGE);
			RecreateViews();
		});
		static const char *vantaResolutions[] = { "1x PSP • original", "2x PSP • nítido", "3x PSP • qualidade", "4x PSP • ultra" };
		PopupMultiChoice *vantaResolution = rightColumnItems->Add(new PopupMultiChoice(&g_Config.iInternalResolution, "Resolução interna", vantaResolutions, 1, ARRAY_SIZE(vantaResolutions), I18NCat::GRAPHICS, screenManager()));
		vantaResolution->OnChoice.Add([this](UI::EventParams &) { System_PostUIMessage(UIMessage::GPU_RENDER_RESIZED); System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED); RecreateViews(); });
		static const char *vantaFrameSkipOptions[] = { "Off", "1", "2", "3" };
		PopupMultiChoice *vantaFrameSkip = rightColumnItems->Add(new PopupMultiChoice(&g_Config.iFrameSkip, "Frame skip", vantaFrameSkipOptions, 0, ARRAY_SIZE(vantaFrameSkipOptions), I18NCat::GRAPHICS, screenManager()));
		vantaFrameSkip->SetEnabledFunc([] { return !g_Config.bAutoFrameSkip; });
		CheckBox *vantaAutoSkip = rightColumnItems->Add(new CheckBox(&g_Config.bAutoFrameSkip, "Auto frameskip"));
		vantaAutoSkip->OnClick.Add([this](UI::EventParams &) { g_Config.UpdateAfterSettingAutoFrameSkip(); RecreateViews(); });
		CheckBox *vantaHWTransform = rightColumnItems->Add(new CheckBox(&g_Config.bHardwareTransform, "Hardware transform"));
		vantaHWTransform->OnClick.Add([](UI::EventParams &) { System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED); });
		CheckBox *vantaSustained = rightColumnItems->Add(new CheckBox(&g_Config.bSustainedPerformanceMode, "Desempenho sustentado"));
		vantaSustained->OnClick.Add([](UI::EventParams &) { System_Notify(SystemNotification::SUSTAINED_PERF_CHANGE); });
	}

	if (vantaPanel == 2) {
		rightColumnItems->Add(new ItemHeader("VISUAL LAB"));
		static const char *vantaAniso[] = { "Off", "2x", "4x", "8x", "16x" };
		PopupMultiChoice *vantaAnisotropy = rightColumnItems->Add(new PopupMultiChoice(&g_Config.iAnisotropyLevel, "Filtro anisotrópico", vantaAniso, 0, ARRAY_SIZE(vantaAniso), I18NCat::GRAPHICS, screenManager()));
		vantaAnisotropy->OnChoice.Add([](UI::EventParams &) { System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED); });
		static const char *vantaTexFilters[] = { "Auto", "Nearest", "Linear", "Auto Max Quality" };
		PopupMultiChoice *vantaTexFilter = rightColumnItems->Add(new PopupMultiChoice(&g_Config.iTexFiltering, "Filtro de textura", vantaTexFilters, 1, ARRAY_SIZE(vantaTexFilters), I18NCat::GRAPHICS, screenManager()));
		vantaTexFilter->OnChoice.Add([](UI::EventParams &) { System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED); });
		CheckBox *vantaSmart2D = rightColumnItems->Add(new CheckBox(&g_Config.bSmart2DTexFiltering, "Smart 2D filtering"));
		vantaSmart2D->OnClick.Add([](UI::EventParams &) { System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED); });
		static const char *vantaTextureScale[] = { "Off", "2x", "3x" };
		PopupMultiChoice *vantaTextureScaleLevel = rightColumnItems->Add(new PopupMultiChoice(&g_Config.iTexScalingLevel, "Upscale de texturas", vantaTextureScale, 1, ARRAY_SIZE(vantaTextureScale), I18NCat::GRAPHICS, screenManager()));
		vantaTextureScaleLevel->OnChoice.Add([](UI::EventParams &) { System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED); });
		static const char *vantaTextureScaleTypes[] = { "xBRZ", "Hybrid", "Bicubic", "Hybrid + Bicubic" };
		PopupMultiChoice *vantaTextureScaleType = rightColumnItems->Add(new PopupMultiChoice(&g_Config.iTexScalingType, "Algoritmo de upscale", vantaTextureScaleTypes, 0, ARRAY_SIZE(vantaTextureScaleTypes), I18NCat::GRAPHICS, screenManager()));
		vantaTextureScaleType->SetEnabledFunc([] { return g_Config.iTexScalingLevel > 1; });
		vantaTextureScaleType->OnChoice.Add([](UI::EventParams &) { System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED); });
		CheckBox *vantaDeposterize = rightColumnItems->Add(new CheckBox(&g_Config.bTexDeposterize, "Deposterize"));
		vantaDeposterize->SetEnabledFunc([] { return g_Config.iTexScalingLevel > 1; });
		vantaDeposterize->OnClick.Add([](UI::EventParams &) { System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED); });
		static int vantaPostChoice = 0;
		if (!g_Config.vPostShaderNames.empty()) {
			const std::string &shader = g_Config.vPostShaderNames.front();
			if (shader == "Sharpen") vantaPostChoice = 1;
			else if (shader == "FXAA") vantaPostChoice = 2;
			else if (shader == "Natural") vantaPostChoice = 3;
			else if (shader == "PSPColor") vantaPostChoice = 4;
			else if (shader == "FSR-RCAS") vantaPostChoice = 5;
			else if (shader == "Bloom") vantaPostChoice = 6;
			else vantaPostChoice = 0;
		} else { vantaPostChoice = 0; }
		static const char *vantaPostShaders[] = { "Off", "Sharpen", "FXAA", "Natural Colors", "PSP Color", "FSR-RCAS", "Bloom" };
		PopupMultiChoice *vantaPost = rightColumnItems->Add(new PopupMultiChoice(&vantaPostChoice, "Pós-processamento", vantaPostShaders, 0, ARRAY_SIZE(vantaPostShaders), I18NCat::GRAPHICS, screenManager()));
		vantaPost->OnChoice.Add([this](UI::EventParams &) {
			g_Config.vPostShaderNames.clear();
			switch (vantaPostChoice) {
			case 1: g_Config.vPostShaderNames.push_back("Sharpen"); break;
			case 2: g_Config.vPostShaderNames.push_back("FXAA"); break;
			case 3: g_Config.vPostShaderNames.push_back("Natural"); break;
			case 4: g_Config.vPostShaderNames.push_back("PSPColor"); break;
			case 5: g_Config.vPostShaderNames.push_back("FSR-RCAS"); break;
			case 6: g_Config.vPostShaderNames.push_back("Bloom"); break;
			default: break;
			}
			g_Config.bShaderChainRequires60FPS = false;
			System_PostUIMessage(UIMessage::POSTSHADER_UPDATED);
			System_PostUIMessage(UIMessage::GPU_RENDER_RESIZED);
			System_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED);
			RecreateViews();
		});
	}

	if (vantaPanel == 3) {
		rightColumnItems->Add(new ItemHeader("SAVE HUB"));
		static const char *vantaSaveSlots[] = { "Slot 1", "Slot 2", "Slot 3", "Slot 4", "Slot 5" };
		if (g_Config.iCurrentStateSlot < 0 || g_Config.iCurrentStateSlot > 4) g_Config.iCurrentStateSlot = 0;
		PopupMultiChoice *vantaSlot = rightColumnItems->Add(new PopupMultiChoice(&g_Config.iCurrentStateSlot, "Slot do Save State", vantaSaveSlots, 0, ARRAY_SIZE(vantaSaveSlots), I18NCat::GRAPHICS, screenManager()));
		vantaSlot->OnChoice.Add([this](UI::EventParams &) { SaveState::Rescan(saveStatePrefix_); RecreateViews(); });
		Choice *vantaSaveNow = rightColumnItems->Add(new Choice(StringFromFormat("Salvar estado agora • Slot %d", g_Config.iCurrentStateSlot + 1), ImageID("I_GEAR")));
		vantaSaveNow->OnClick.Add([this](UI::EventParams &) {
			if (!Achievements::WarnUserIfHardcoreModeActive(true) && !NetworkWarnUserIfOnlineAndCantSavestate() && !bootPending_) {
				if (g_Config.memStickDirectory.empty() || !CreateSysDirectories()) { g_OSD.Show(OSDType::MESSAGE_ERROR, "VANTA: Memory Card não está disponível para escrita.", 5.0f); return; }
				SaveState::Rescan(saveStatePrefix_);
				SaveState::SaveSlot(saveStatePrefix_, g_Config.iCurrentStateSlot, &AfterSaveStateAction);
				TriggerFinish(DR_OK);
			}
		});
		SaveState::Rescan(saveStatePrefix_);
		Choice *vantaLoadNow = rightColumnItems->Add(new Choice(StringFromFormat("Carregar estado • Slot %d", g_Config.iCurrentStateSlot + 1), ImageID("I_PLAY")));
		vantaLoadNow->SetEnabled(SaveState::HasSaveInSlot(saveStatePrefix_, g_Config.iCurrentStateSlot));
		vantaLoadNow->OnClick.Add([this](UI::EventParams &) {
			if (!Achievements::WarnUserIfHardcoreModeActive(false) && !NetworkWarnUserIfOnlineAndCantSavestate() && !bootPending_ && SaveState::HasSaveInSlot(saveStatePrefix_, g_Config.iCurrentStateSlot)) {
				SaveState::LoadSlot(saveStatePrefix_, g_Config.iCurrentStateSlot, &AfterSaveStateAction);
				TriggerFinish(DR_OK);
			}
		});
		rightColumnItems->Add(new Choice("Memory Card • Gerenciar savedata", ImageID("I_FOLDER")))->OnClick.Add([this](UI::EventParams &) { screenManager()->push(new SavedataScreen(gamePath_)); });
	}

	rightColumnItems->Add(new Spacer(12.0));
'''
    text = text[:start] + quick_tune + text[end:]

    display_block = '''\trightColumnItems->Add(new Choice(gr->T("Display layout & effects"), ImageID("I_DISPLAY")))->OnClick.Add([this](UI::EventParams &) -> void {\n\t\tscreenManager()->push(new DisplayLayoutScreen(gamePath_));\n\t});\n'''
    if display_block in text:
        text = text.replace(display_block, '\t// VANTA: display settings are managed by the VANTA shell.\n', 1)
    if "ShowMessageAfterSaveStateAction" in text:
        fail("incompatible savestate callback for PPSSPP v1.20.4")
    path.write_text(text, encoding="utf-8")

def copy_overlay(project_root: Path, upstream_root: Path) -> None:
    overlay_root = project_root / "overlay"
    for src in overlay_root.rglob("*"):
        if src.is_dir():
            continue
        rel = src.relative_to(overlay_root)
        dst = upstream_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def write_marker(root: Path) -> None:
    (root / "assets" / "vanta_build.txt").write_text(
        "VANTA PSP Unified Final\nEngine: PPSSPP v1.20.4\nTarget: Android ARM64 normalOptimized\n",
        encoding="utf-8")

def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: apply_vanta.py <ppsspp-source-directory>")
    upstream_root = Path(sys.argv[1]).resolve()
    project_root = Path(__file__).resolve().parent.parent
    required = [
        upstream_root / "android" / "build.gradle.kts",
        upstream_root / "android" / "AndroidManifest.xml",
        upstream_root / "android" / "res" / "values" / "strings.xml",
        upstream_root / "android" / "src" / "org" / "ppsspp" / "ppsspp" / "NativeApp.java",
        upstream_root / "android" / "src" / "org" / "ppsspp" / "ppsspp" / "PpssppActivity.java",
        upstream_root / "android" / "jni" / "app-android.cpp",
        upstream_root / "UI" / "NativeApp.cpp",
        upstream_root / "UI" / "PauseScreen.cpp",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        fail("not a compatible PPSSPP v1.20.4 tree; missing: " + ", ".join(missing))
    patch_gradle(upstream_root)
    patch_strings(upstream_root)
    patch_manifest(upstream_root)
    patch_nativeapp_java(upstream_root)
    patch_activity(upstream_root)
    patch_native_cpp(upstream_root)
    patch_vanta_storage(upstream_root)
    patch_pause_screen(upstream_root)
    copy_overlay(project_root, upstream_root)
    write_marker(upstream_root)
    print("VANTA final layer applied successfully.")

if __name__ == "__main__":
    main()
