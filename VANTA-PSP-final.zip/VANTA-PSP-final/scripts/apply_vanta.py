#!/usr/bin/env python3
from __future__ import annotations
import shutil
import sys
from pathlib import Path

APP_ID = "com.vantapsp.emulator"
APP_NAME = "VANTA PSP"

def fail(message: str) -> None:
    raise SystemExit(f"VANTA patch error: {message}")

def replace_required(text: str, old: str, new: str, *, count: int = 1, label: str = "patch") -> str:
    hits = text.count(old)
    if hits < count:
        fail(f"upstream changed; {label}: expected >= {count}, found {hits}")
    return text.replace(old, new, count)

def patch_gradle(root: Path) -> None:
    path = root / "android" / "build.gradle.kts"
    text = path.read_text(encoding="utf-8")
    if 'applicationId = "org.ppsspp.ppsspp"' not in text:
        fail("Android applicationId anchor missing")
    text = text.replace('applicationId = "org.ppsspp.ppsspp"', f'applicationId = "{APP_ID}"')
    text = replace_required(text,
        'abiFilters.addAll(listOf("armeabi-v7a", "arm64-v8a", "x86_64"))',
        'abiFilters.add("arm64-v8a")',
        label="normal ARM64 ABI filter")
    old = '''create("optimized") {
\t\t\tisMinifyEnabled = false
\t\t\tisJniDebuggable = true
\t\t\tsigningConfig = signingConfigs.getByName("debug")
\t\t}'''
    new = '''create("optimized") {
\t\t\tisMinifyEnabled = false
\t\t\tisJniDebuggable = false
\t\t\tsigningConfig = signingConfigs.getByName("debug")
\t\t}'''
    text = replace_required(text, old, new, label="optimized build type")
    path.write_text(text, encoding="utf-8")

def patch_strings(root: Path) -> None:
    path = root / "android" / "res" / "values" / "strings.xml"
    text = path.read_text(encoding="utf-8")
    text = replace_required(text, '<string name="app_name">PPSSPP</string>',
        f'<string name="app_name">{APP_NAME}</string>', label="app name")
    text = replace_required(text, '<string name="shortcut_name">PPSSPP game</string>',
        '<string name="shortcut_name">VANTA game</string>', label="shortcut name")
    path.write_text(text, encoding="utf-8")

def patch_manifest(root: Path) -> None:
    path = root / "android" / "AndroidManifest.xml"
    text = path.read_text(encoding="utf-8")
    launcher = '''            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
'''
    text = replace_required(text, launcher, "", label="PPSSPP launcher filter")
    marker = '''        <activity
            android:name=".PpssppActivity"'''
    insert = '''        <activity
            android:name=".VantaActivity"
            android:configChanges="locale|keyboard|keyboardHidden|navigation|orientation|screenSize|uiMode"
            android:screenOrientation="sensorLandscape"
            android:theme="@style/ppsspp_style"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".PpssppActivity"'''
    text = replace_required(text, marker, insert, label="VANTA launcher activity")
    path.write_text(text, encoding="utf-8")

def patch_nativeapp_java(root: Path) -> None:
    path = root / "android" / "src" / "org" / "ppsspp" / "ppsspp" / "NativeApp.java"
    text = path.read_text(encoding="utf-8")
    anchor = '\tpublic static native String queryConfig(String queryName);'
    addition = '''\tpublic static native void vantaSetBootConfig(int backend, int resolution, int frameSkip,
\t\tboolean autoFrameSkip, boolean fastMemory, boolean hardwareTransform, boolean sustainedPerformance);
\tpublic static native String queryConfig(String queryName);'''
    text = replace_required(text, anchor, addition, label="NativeApp VANTA JNI declaration")
    path.write_text(text, encoding="utf-8")

def patch_activity(root: Path) -> None:
    path = root / "android" / "src" / "org" / "ppsspp" / "ppsspp" / "PpssppActivity.java"
    text = path.read_text(encoding="utf-8")
    anchor = '''\t\tNativeApp.audioConfig(optimalFramesPerBuffer, optimalSampleRate);
\t\tNativeApp.init(model, deviceType, languageRegion, apkFilePath, dataDir, extStorageDir, externalFilesDir, nativeLibDir, additionalStorageDirs, cacheDir, shortcut, installerName, Build.VERSION.SDK_INT, Build.BOARD);'''
    replacement = '''\t\tIntent vantaIntent = getIntent();
\t\tif (vantaIntent != null && vantaIntent.getBooleanExtra("vanta_managed", false)) {
\t\t\tNativeApp.vantaSetBootConfig(
\t\t\t\tvantaIntent.getIntExtra("vanta_backend", 3),
\t\t\t\tvantaIntent.getIntExtra("vanta_resolution", 2),
\t\t\t\tvantaIntent.getIntExtra("vanta_frameskip", 0),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_auto_frameskip", false),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_fast_memory", true),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_hardware_transform", true),
\t\t\t\tvantaIntent.getBooleanExtra("vanta_sustained_performance", false)
\t\t\t);
\t\t}

\t\tNativeApp.audioConfig(optimalFramesPerBuffer, optimalSampleRate);
\t\tNativeApp.init(model, deviceType, languageRegion, apkFilePath, dataDir, extStorageDir, externalFilesDir, nativeLibDir, additionalStorageDirs, cacheDir, shortcut, installerName, Build.VERSION.SDK_INT, Build.BOARD);'''
    text = replace_required(text, anchor, replacement, label="PpssppActivity VANTA boot config")
    path.write_text(text, encoding="utf-8")

def patch_native_cpp(root: Path) -> None:
    path = root / "android" / "jni" / "app-android.cpp"
    text = path.read_text(encoding="utf-8")
    include_anchor = "#include <cstdlib>\n#include <cstdint>"
    include_replacement = "#include <algorithm>\n#include <cstdlib>\n#include <cstdint>"
    text = replace_required(text, include_anchor, include_replacement, label="C++ algorithm include")
    anchor = '''extern "C" void Java_org_ppsspp_ppsspp_NativeApp_audioConfig
\t(JNIEnv *env, jclass, jint optimalFPB, jint optimalSR) {
\toptimalFramesPerBuffer = optimalFPB;
\toptimalSampleRate = optimalSR;
}'''
    addition = anchor + r'''

struct VantaBootConfig {
	bool pending = false;
	int backend = 3;
	int resolution = 2;
	int frameSkip = 0;
	bool autoFrameSkip = false;
	bool fastMemory = true;
	bool hardwareTransform = true;
	bool sustainedPerformance = false;
};

static VantaBootConfig g_vantaBootConfig;

extern "C" void Java_org_ppsspp_ppsspp_NativeApp_vantaSetBootConfig(
	JNIEnv *, jclass, jint backend, jint resolution, jint frameSkip,
	jboolean autoFrameSkip, jboolean fastMemory, jboolean hardwareTransform, jboolean sustainedPerformance) {
	g_vantaBootConfig.pending = true;
	g_vantaBootConfig.backend = backend;
	g_vantaBootConfig.resolution = resolution;
	g_vantaBootConfig.frameSkip = frameSkip;
	g_vantaBootConfig.autoFrameSkip = autoFrameSkip;
	g_vantaBootConfig.fastMemory = fastMemory;
	g_vantaBootConfig.hardwareTransform = hardwareTransform;
	g_vantaBootConfig.sustainedPerformance = sustainedPerformance;
}'''
    text = replace_required(text, anchor, addition, label="VANTA boot config JNI")
    init_anchor = '''\tNativeInit((int)args.size(), &args[0], user_data_path.c_str(), externalStorageDir.c_str(), cacheDir.c_str());

\tbFirstResume = true;'''
    init_replace = '''\tNativeInit((int)args.size(), &args[0], user_data_path.c_str(), externalStorageDir.c_str(), cacheDir.c_str());

	if (g_vantaBootConfig.pending) {
		int backend = g_vantaBootConfig.backend;
		if (backend != (int)GPUBackend::OPENGL && backend != (int)GPUBackend::VULKAN)
			backend = (int)GPUBackend::VULKAN;

		g_Config.iGPUBackend = backend;
		SetGPUBackend((GPUBackend)backend);
		g_Config.iInternalResolution = std::clamp(g_vantaBootConfig.resolution, 1, 4);
		g_Config.iFrameSkip = std::clamp(g_vantaBootConfig.frameSkip, 0, 3);
		g_Config.bAutoFrameSkip = g_vantaBootConfig.autoFrameSkip;
		g_Config.bFastMemory = g_vantaBootConfig.fastMemory;
		g_Config.bHardwareTransform = g_vantaBootConfig.hardwareTransform;
		g_Config.bSustainedPerformanceMode = g_vantaBootConfig.sustainedPerformance;
		g_Config.bPauseMenuExitsEmulator = true;

		INFO_LOG(Log::System,
			"VANTA profile: backend=%d resolution=%d frameskip=%d auto=%d fastmem=%d hwtransform=%d sustained=%d",
			g_Config.iGPUBackend, g_Config.iInternalResolution, g_Config.iFrameSkip,
			(int)g_Config.bAutoFrameSkip, (int)g_Config.bFastMemory,
			(int)g_Config.bHardwareTransform, (int)g_Config.bSustainedPerformanceMode);

		g_vantaBootConfig.pending = false;
	}

	bFirstResume = true;'''
    text = replace_required(text, init_anchor, init_replace, label="VANTA runtime profile application")
    if r"\tNativeInit" in text:
        fail("escaped tab leaked into C++ source")
    path.write_text(text, encoding="utf-8")

def patch_pause_screen(root: Path) -> None:
    path = root / "UI" / "PauseScreen.cpp"
    text = path.read_text(encoding="utf-8")
    start = text.find('\tif (g_paramSFO.IsValid() && g_Config.HasGameConfig(g_paramSFO.GetDiscID())) {')
    end_marker = '\n\tif (g_Config.bAchievementsEnable && Achievements::HasAchievementsOrLeaderboards()) {'
    end = text.find(end_marker, start)
    if start == -1 or end == -1:
        fail("PauseScreen settings block anchors missing")
    quick_tune = '''\t// VANTA: native quick-tune menu replaces the generic PPSSPP settings entry.\n\trightColumnItems->Add(new ItemHeader("VANTA QUICK TUNE"));\n\n\tauto vantaProfileName = []() -> std::string {\n\t\tif (g_Config.iInternalResolution == 1 && g_Config.iFrameSkip == 1 && g_Config.bAutoFrameSkip) return "Turbo";\n\t\tif (g_Config.iInternalResolution >= 3 && g_Config.iFrameSkip == 0 && !g_Config.bAutoFrameSkip) return "Quality";\n\t\tif (g_Config.iInternalResolution == 1 && g_Config.iFrameSkip == 0 && !g_Config.bAutoFrameSkip && g_Config.bSustainedPerformanceMode) return "Battery";\n\t\tif (g_Config.iInternalResolution == 2 && g_Config.iFrameSkip == 0 && !g_Config.bAutoFrameSkip) return "Balanced";\n\t\treturn "Custom";\n\t};\n\n\tChoice *vantaProfile = rightColumnItems->Add(new Choice(std::string("Perfil VANTA • ") + vantaProfileName(), ImageID("I_GEAR")));\n\tvantaProfile->OnClick.Add([this, vantaProfileName](UI::EventParams &) {\n\t\tstd::string current = vantaProfileName();\n\t\tif (current == "Balanced") {\n\t\t\tg_Config.iInternalResolution = 1;\n\t\t\tg_Config.iFrameSkip = 1;\n\t\t\tg_Config.bAutoFrameSkip = true;\n\t\t\tg_Config.bSustainedPerformanceMode = false;\n\t\t} else if (current == "Turbo") {\n\t\t\tg_Config.iInternalResolution = 3;\n\t\t\tg_Config.iFrameSkip = 0;\n\t\t\tg_Config.bAutoFrameSkip = false;\n\t\t\tg_Config.bSustainedPerformanceMode = false;\n\t\t} else if (current == "Quality") {\n\t\t\tg_Config.iInternalResolution = 1;\n\t\t\tg_Config.iFrameSkip = 0;\n\t\t\tg_Config.bAutoFrameSkip = false;\n\t\t\tg_Config.bSustainedPerformanceMode = true;\n\t\t} else {\n\t\t\tg_Config.iInternalResolution = 2;\n\t\t\tg_Config.iFrameSkip = 0;\n\t\t\tg_Config.bAutoFrameSkip = false;\n\t\t\tg_Config.bSustainedPerformanceMode = false;\n\t\t}\n\t\tg_Config.bFastMemory = true;\n\t\tg_Config.bHardwareTransform = true;\n\t\tSystem_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED);\n\t\tSystem_Notify(SystemNotification::SUSTAINED_PERF_CHANGE);\n\t\tRecreateViews();\n\t});\n\n\tChoice *vantaResolution = rightColumnItems->Add(new Choice(std::string("Resolução interna • ") + std::to_string(g_Config.iInternalResolution) + "x", ImageID("I_DISPLAY")));\n\tvantaResolution->OnClick.Add([this](UI::EventParams &) {\n\t\tg_Config.iInternalResolution++;\n\t\tif (g_Config.iInternalResolution > 4 || g_Config.iInternalResolution < 1) g_Config.iInternalResolution = 1;\n\t\tSystem_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED);\n\t\tRecreateViews();\n\t});\n\n\tChoice *vantaFrameSkip = rightColumnItems->Add(new Choice(std::string("Frame skip • ") + (g_Config.iFrameSkip == 0 ? "Off" : std::to_string(g_Config.iFrameSkip)), ImageID("I_GEAR")));\n\tvantaFrameSkip->OnClick.Add([this](UI::EventParams &) {\n\t\tg_Config.iFrameSkip = (g_Config.iFrameSkip + 1) % 4;\n\t\tRecreateViews();\n\t});\n\n\tChoice *vantaAutoSkip = rightColumnItems->Add(new Choice(std::string("Auto frameskip • ") + (g_Config.bAutoFrameSkip ? "Ligado" : "Desligado"), ImageID("I_GEAR")));\n\tvantaAutoSkip->OnClick.Add([this](UI::EventParams &) {\n\t\tg_Config.bAutoFrameSkip = !g_Config.bAutoFrameSkip;\n\t\tRecreateViews();\n\t});\n\n\tChoice *vantaHWTransform = rightColumnItems->Add(new Choice(std::string("Hardware transform • ") + (g_Config.bHardwareTransform ? "Ligado" : "Desligado"), ImageID("I_DISPLAY")));\n\tvantaHWTransform->OnClick.Add([this](UI::EventParams &) {\n\t\tg_Config.bHardwareTransform = !g_Config.bHardwareTransform;\n\t\tSystem_PostUIMessage(UIMessage::GPU_CONFIG_CHANGED);\n\t\tRecreateViews();\n\t});\n\n\trightColumnItems->Add(new Spacer(14.0));\n'''
    text = text[:start] + quick_tune + text[end:]
    display_block = '''\trightColumnItems->Add(new Choice(gr->T("Display layout & effects"), ImageID("I_DISPLAY")))->OnClick.Add([this](UI::EventParams &) -> void {
\t\tscreenManager()->push(new DisplayLayoutScreen(gamePath_));
\t});
'''
    if display_block in text:
        text = text.replace(display_block, '\t// VANTA: display settings are managed by the VANTA shell.\n', 1)
    path.write_text(text, encoding="utf-8")

def copy_overlay(project_root: Path, upstream_root: Path) -> None:
    overlay_root = project_root / "overlay"
    for src in overlay_root.rglob("*"):
        if src.is_dir():
            continue
        rel = src.relative_to(overlay_root)
        dst = upstream_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def write_marker(root: Path) -> None:
    (root / "assets" / "vanta_build.txt").write_text(
        "VANTA PSP Unified Final\nEngine: PPSSPP v1.20.4\nTarget: Android ARM64 normalOptimized\n",
        encoding="utf-8")

def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: apply_vanta.py <ppsspp-source-directory>")
    upstream_root = Path(sys.argv[1]).resolve()
    project_root = Path(__file__).resolve().parent.parent
    required = [
        upstream_root / "android" / "build.gradle.kts",
        upstream_root / "android" / "AndroidManifest.xml",
        upstream_root / "android" / "res" / "values" / "strings.xml",
        upstream_root / "android" / "src" / "org" / "ppsspp" / "ppsspp" / "NativeApp.java",
        upstream_root / "android" / "src" / "org" / "ppsspp" / "ppsspp" / "PpssppActivity.java",
        upstream_root / "android" / "jni" / "app-android.cpp",
        upstream_root / "UI" / "PauseScreen.cpp",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        fail("not a compatible PPSSPP v1.20.4 tree; missing: " + ", ".join(missing))
    patch_gradle(upstream_root)
    patch_strings(upstream_root)
    patch_manifest(upstream_root)
    patch_nativeapp_java(upstream_root)
    patch_activity(upstream_root)
    patch_native_cpp(upstream_root)
    patch_pause_screen(upstream_root)
    copy_overlay(project_root, upstream_root)
    write_marker(upstream_root)
    print("VANTA final layer applied successfully.")

if __name__ == "__main__":
    main()
