package org.ppsspp.ppsspp;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class VantaPrefs {
    private static final String NAME = "vanta_unified";
    public static final int BACKEND_OPENGL = 0;
    public static final int BACKEND_VULKAN = 3;

    private VantaPrefs() {}

    public static final class GameEntry {
        public final String name;
        public final String uri;
        public GameEntry(String name, String uri) {
            this.name = name == null || name.trim().isEmpty() ? "Jogo PSP" : name;
            this.uri = uri == null ? "" : uri;
        }
    }

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static String profile(Context c) { return p(c).getString("profile", "Balanced"); }
    public static int backend(Context c) { return p(c).getInt("backend", BACKEND_VULKAN); }
    public static int resolution(Context c) { return clamp(p(c).getInt("resolution", 2), 1, 4); }
    public static int frameSkip(Context c) { return clamp(p(c).getInt("frameskip", 0), 0, 3); }
    public static boolean autoFrameSkip(Context c) { return p(c).getBoolean("auto_frameskip", false); }
    public static boolean fastMemory(Context c) { return p(c).getBoolean("fast_memory", true); }
    public static boolean hardwareTransform(Context c) { return p(c).getBoolean("hardware_transform", true); }
    public static boolean sustainedPerformance(Context c) { return p(c).getBoolean("sustained_performance", false); }

    public static void setProfile(Context c, String v) { p(c).edit().putString("profile", v).apply(); }
    public static void setBackend(Context c, int v) { p(c).edit().putInt("backend", v).apply(); }
    public static void setResolution(Context c, int v) { p(c).edit().putInt("resolution", clamp(v, 1, 4)).apply(); }
    public static void setFrameSkip(Context c, int v) { p(c).edit().putInt("frameskip", clamp(v, 0, 3)).apply(); }
    public static void setAutoFrameSkip(Context c, boolean v) { p(c).edit().putBoolean("auto_frameskip", v).apply(); }
    public static void setFastMemory(Context c, boolean v) { p(c).edit().putBoolean("fast_memory", v).apply(); }
    public static void setHardwareTransform(Context c, boolean v) { p(c).edit().putBoolean("hardware_transform", v).apply(); }
    public static void setSustainedPerformance(Context c, boolean v) { p(c).edit().putBoolean("sustained_performance", v).apply(); }

    public static void applyPreset(Context c, String preset) {
        SharedPreferences.Editor e = p(c).edit().putString("profile", preset);
        switch (preset) {
            case "Turbo":
                e.putInt("backend", BACKEND_VULKAN).putInt("resolution", 1).putInt("frameskip", 1)
                    .putBoolean("auto_frameskip", true).putBoolean("fast_memory", true)
                    .putBoolean("hardware_transform", true).putBoolean("sustained_performance", true);
                break;
            case "Quality":
                e.putInt("backend", BACKEND_VULKAN).putInt("resolution", 3).putInt("frameskip", 0)
                    .putBoolean("auto_frameskip", false).putBoolean("fast_memory", true)
                    .putBoolean("hardware_transform", true).putBoolean("sustained_performance", false);
                break;
            case "Battery":
                e.putInt("backend", BACKEND_VULKAN).putInt("resolution", 1).putInt("frameskip", 0)
                    .putBoolean("auto_frameskip", false).putBoolean("fast_memory", true)
                    .putBoolean("hardware_transform", true).putBoolean("sustained_performance", false);
                break;
            case "Balanced":
            default:
                e.putInt("backend", BACKEND_VULKAN).putInt("resolution", 2).putInt("frameskip", 0)
                    .putBoolean("auto_frameskip", false).putBoolean("fast_memory", true)
                    .putBoolean("hardware_transform", true).putBoolean("sustained_performance", false);
                break;
        }
        e.apply();
    }

    public static String treeUri(Context c) { return p(c).getString("tree_uri", ""); }
    public static void setTreeUri(Context c, String uri) {
        p(c).edit().putString("tree_uri", uri == null ? "" : uri).apply();
    }

    public static void setLastGame(Context c, GameEntry game) {
        p(c).edit().putString("last_game_name", game.name).putString("last_game_uri", game.uri).apply();
        addRecent(c, game);
    }

    public static GameEntry lastGame(Context c) {
        String uri = p(c).getString("last_game_uri", "");
        if (uri == null || uri.isEmpty()) return null;
        return new GameEntry(p(c).getString("last_game_name", "Jogo PSP"), uri);
    }

    public static List<GameEntry> recents(Context c) {
        List<GameEntry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("recents", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                String uri = o.optString("uri", "");
                if (!uri.isEmpty()) out.add(new GameEntry(o.optString("name", "Jogo PSP"), uri));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static void addRecent(Context c, GameEntry game) {
        List<GameEntry> old = recents(c);
        JSONArray a = new JSONArray();
        try {
            JSONObject first = new JSONObject();
            first.put("name", game.name);
            first.put("uri", game.uri);
            a.put(first);
            int count = 1;
            for (GameEntry item : old) {
                if (item.uri.equals(game.uri)) continue;
                JSONObject o = new JSONObject();
                o.put("name", item.name);
                o.put("uri", item.uri);
                a.put(o);
                if (++count >= 10) break;
            }
        } catch (Exception ignored) {}
        p(c).edit().putString("recents", a.toString()).apply();
    }

    public static boolean isFavorite(Context c, String uri) {
        return p(c).getStringSet("favorites", new HashSet<>()).contains(uri);
    }

    public static boolean toggleFavorite(Context c, String uri) {
        Set<String> set = new HashSet<>(p(c).getStringSet("favorites", new HashSet<>()));
        boolean now;
        if (set.contains(uri)) { set.remove(uri); now = false; }
        else { set.add(uri); now = true; }
        p(c).edit().putStringSet("favorites", set).apply();
        return now;
    }

    public static void reset(Context c) {
        p(c).edit().clear().apply();
        applyPreset(c, "Balanced");
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
}
