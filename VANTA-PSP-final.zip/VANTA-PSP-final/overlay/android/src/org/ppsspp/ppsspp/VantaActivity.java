package org.ppsspp.ppsspp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class VantaActivity extends Activity {
    private static final int REQ_PICK_GAME = 1201;
    private static final int REQ_PICK_TREE = 1202;

    private static final int BG = Color.rgb(5, 7, 12);
    private static final int PANEL = Color.rgb(13, 18, 31);
    private static final int PANEL_2 = Color.rgb(19, 26, 44);
    private static final int STROKE = Color.rgb(43, 57, 88);
    private static final int TEXT = Color.rgb(244, 248, 255);
    private static final int MUTED = Color.rgb(150, 164, 196);
    private static final int CYAN = Color.rgb(110, 231, 249);
    private static final int BLUE = Color.rgb(79, 140, 255);
    private static final int GREEN = Color.rgb(88, 220, 168);

    private enum Page { HOME, LIBRARY, PERFORMANCE, VISUAL, SAVES, CONTROLS, ABOUT }

    private FrameLayout content;
    private final Map<Page, Button> nav = new HashMap<>();
    private Page currentPage = Page.HOME;
    private TextView inputMonitor;
    private EditText librarySearch;
    private GridLayout libraryGrid;
    private TextView libraryStatus;
    private List<VantaPrefs.GameEntry> libraryGames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();
        ensureVantaMemoryCard();
        buildShell();
        show(Page.HOME);
    }

    @Override
    protected void onResume() {
        super.onResume();
        immersive();
        if (content != null) show(currentPage);
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(BG);

        LinearLayout rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        boolean compact = isCompact();
        rail.setPadding(dp(compact ? 12 : 16), dp(18), dp(compact ? 12 : 16), dp(14));
        rail.setBackground(gradient(PANEL, Color.rgb(8, 11, 19), 0, 0, 0));
        root.addView(rail, new LinearLayout.LayoutParams(dp(compact ? 174 : 204), -1));

        TextView logo = text("VANTA", isCompact() ? 24 : 28, TEXT, true);
        logo.setLetterSpacing(0.15f);
        rail.addView(logo);

        TextView sub = text("PSP  /  UNIFIED", 11, MUTED, true);
        sub.setLetterSpacing(0.10f);
        sub.setPadding(0, dp(6), 0, dp(16));
        rail.addView(sub);

        addNav(rail, Page.HOME, "Início", "⌂");
        addNav(rail, Page.LIBRARY, "Biblioteca", "▦");
        addNav(rail, Page.PERFORMANCE, "Performance", "⚡");
        addNav(rail, Page.VISUAL, "Visual", "◈");
        addNav(rail, Page.SAVES, "Saves", "▣");
        addNav(rail, Page.CONTROLS, "Controles", "⌁");
        addNav(rail, Page.ABOUT, "Sistema", "●");

        Space fill = new Space(this);
        rail.addView(fill, new LinearLayout.LayoutParams(1, 0, 1f));

        TextView core = text("CORE 1.20.4\nARM64 • OPTIMIZED", 11, MUTED, true);
        core.setLineSpacing(0, 1.25f);
        rail.addView(core);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(0, -1, 1f));
        setContentView(root);
    }

    private void addNav(LinearLayout rail, Page page, String label, String icon) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        b.setText(icon + "    " + label);
        b.setTextSize(isCompact() ? 13 : 14);
        b.setTextColor(MUTED);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setPadding(dp(16), 0, dp(12), 0);
        b.setFocusable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(isCompact() ? 46 : 50));
        lp.setMargins(0, 0, 0, dp(8));
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> show(page));
        rail.addView(b);
        nav.put(page, b);
    }

    private void show(Page page) {
        currentPage = page;
        for (Map.Entry<Page, Button> e : nav.entrySet()) {
            boolean active = e.getKey() == page;
            e.getValue().setTextColor(active ? TEXT : MUTED);
            e.getValue().setBackground(round(active ? PANEL_2 : Color.TRANSPARENT,
                active ? STROKE : Color.TRANSPARENT, 16));
        }

        content.removeAllViews();
        View pageView;
        switch (page) {
            case LIBRARY: pageView = libraryPage(); break;
            case PERFORMANCE: pageView = performancePage(); break;
            case VISUAL: pageView = visualPage(); break;
            case SAVES: pageView = savesPage(); break;
            case CONTROLS: pageView = controlsPage(); break;
            case ABOUT: pageView = aboutPage(); break;
            case HOME:
            default: pageView = homePage(); break;
        }
        content.addView(pageView, new FrameLayout.LayoutParams(-1, -1));
    }

    private ScrollView pageScroller() {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        s.setBackgroundColor(BG);
        return s;
    }

    private LinearLayout pageColumn(String eyebrow, String title, String subtitle) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(isCompact() ? 20 : 28), dp(20), dp(isCompact() ? 20 : 28), dp(24));
        TextView eye = text(eyebrow.toUpperCase(Locale.ROOT), 11, CYAN, true);
        eye.setLetterSpacing(0.12f);
        col.addView(eye);
        TextView h = text(title, isCompact() ? 25 : 29, TEXT, true);
        h.setPadding(0, dp(6), 0, 0);
        col.addView(h);
        TextView p = text(subtitle, isCompact() ? 12 : 14, MUTED, false);
        p.setPadding(0, dp(6), 0, dp(16));
        col.addView(p);
        return col;
    }

    private View homePage() {
        ScrollView s = pageScroller();
        LinearLayout col = pageColumn("VANTA OS", "Pronto para jogar.",
            "Escolha o jogo, veja o perfil ativo e entre direto na emulação.");

        LinearLayout hero = card();
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(18), dp(20), dp(18));

        LinearLayout heroTop = new LinearLayout(this);
        heroTop.setOrientation(LinearLayout.HORIZONTAL);
        heroTop.setGravity(Gravity.CENTER_VERTICAL);
        hero.addView(heroTop, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout heroCopy = new LinearLayout(this);
        heroCopy.setOrientation(LinearLayout.VERTICAL);
        heroTop.addView(heroCopy, new LinearLayout.LayoutParams(0, -2, 1f));
        heroCopy.addView(text("Biblioteca VANTA", isCompact() ? 21 : 25, TEXT, true));
        TextView heroSub = text("Sem menus duplicados. Seu jogo abre direto pelo VANTA.", isCompact() ? 11 : 13, MUTED, false);
        heroSub.setPadding(0, dp(5), dp(12), 0);
        heroCopy.addView(heroSub);

        LinearLayout profileMini = new LinearLayout(this);
        profileMini.setOrientation(LinearLayout.VERTICAL);
        profileMini.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        heroTop.addView(profileMini, new LinearLayout.LayoutParams(dp(isCompact() ? 150 : 190), -2));
        TextView profileLabel = text("PERFIL", 9, MUTED, true);
        profileLabel.setGravity(Gravity.RIGHT);
        profileMini.addView(profileLabel, new LinearLayout.LayoutParams(-1, -2));
        TextView profile = text(VantaPrefs.profile(this).toUpperCase(Locale.ROOT), isCompact() ? 15 : 18, CYAN, true);
        profile.setGravity(Gravity.RIGHT);
        profile.setPadding(0, dp(4), 0, 0);
        profileMini.addView(profile, new LinearLayout.LayoutParams(-1, -2));
        TextView render = text(backendName() + " • " + VantaPrefs.resolution(this) + "x", 10, MUTED, true);
        render.setGravity(Gravity.RIGHT);
        profileMini.addView(render, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, dp(50));
        alp.topMargin = dp(16);
        hero.addView(actions, alp);

        Button play = primary("Escolher jogo");
        play.setOnClickListener(v -> pickGame());
        actions.addView(play, new LinearLayout.LayoutParams(0, -1, 1f));
        actions.addView(new Space(this), new LinearLayout.LayoutParams(dp(10), 1));

        VantaPrefs.GameEntry last = VantaPrefs.lastGame(this);
        Button resume = secondary(last == null ? "Sem jogo recente" : "Continuar último");
        resume.setEnabled(last != null);
        resume.setAlpha(last == null ? 0.45f : 1f);
        resume.setOnClickListener(v -> { VantaPrefs.GameEntry g = VantaPrefs.lastGame(this); if (g != null) launch(g); });
        actions.addView(resume, new LinearLayout.LayoutParams(0, -1, 1f));

        TextView quickHint = text("Dentro do jogo: botão voltar → VANTA Quick Tune + Save Hub. Ajuste desempenho e salve/carregue estados sem sair.",
            isCompact() ? 10 : 11, MUTED, false);
        quickHint.setPadding(0, dp(12), 0, 0);
        hero.addView(quickHint);

        col.addView(hero, matchWrapMargin(0, 0, 0, dp(14)));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard("PERFIL", VantaPrefs.profile(this), backendName()), weightMargin(1f, 0, 0, dp(6), 0));
        stats.addView(statCard("RESOLUÇÃO", VantaPrefs.resolution(this) + "x", "interna"), weightMargin(1f, dp(6), 0, dp(6), 0));
        stats.addView(statCard("FRAMESKIP", String.valueOf(VantaPrefs.frameSkip(this)), VantaPrefs.autoFrameSkip(this) ? "auto ligado" : "auto desligado"), weightMargin(1f, dp(6), 0, 0, 0));
        col.addView(stats);

        LinearLayout recentHeader = new LinearLayout(this);
        recentHeader.setOrientation(LinearLayout.HORIZONTAL);
        recentHeader.setGravity(Gravity.CENTER_VERTICAL);
        recentHeader.setPadding(0, dp(18), 0, dp(9));
        TextView recentTitle = text("Recentes", 18, TEXT, true);
        recentHeader.addView(recentTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        Button library = secondary("Ver biblioteca");
        library.setOnClickListener(v -> show(Page.LIBRARY));
        recentHeader.addView(library, new LinearLayout.LayoutParams(dp(140), dp(42)));
        col.addView(recentHeader);

        List<VantaPrefs.GameEntry> recents = VantaPrefs.recents(this);
        if (recents.isEmpty()) {
            TextView empty = text("Nenhum jogo recente. Use ‘Escolher jogo’ ou adicione uma pasta na Biblioteca.", 12, MUTED, false);
            empty.setPadding(dp(16), dp(16), dp(16), dp(16));
            empty.setBackground(round(PANEL, STROKE, 16));
            col.addView(empty);
        } else {
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            hs.addView(row);
            int n = Math.min(6, recents.size());
            for (int i = 0; i < n; i++) {
                row.addView(gameTile(recents.get(i), false), new LinearLayout.LayoutParams(dp(isCompact() ? 190 : 220), dp(124)));
                if (i != n - 1) row.addView(new Space(this), new LinearLayout.LayoutParams(dp(10), 1));
            }
            col.addView(hs);
        }

        s.addView(col);
        return s;
    }

    private View libraryPage() {
        ScrollView s = pageScroller();
        LinearLayout col = pageColumn("BIBLIOTECA", "Seus jogos, no mesmo lugar.",
            "Adicione uma pasta uma vez. O VANTA lembra dela e encontra ISO, CSO, CHD, PBP e ELF.");

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        Button folder = primary("Adicionar pasta");
        folder.setOnClickListener(v -> pickTree());
        tools.addView(folder, new LinearLayout.LayoutParams(dp(180), dp(50)));
        tools.addView(new Space(this), new LinearLayout.LayoutParams(dp(10), 1));
        Button file = secondary("Abrir arquivo");
        file.setOnClickListener(v -> pickGame());
        tools.addView(file, new LinearLayout.LayoutParams(dp(160), dp(50)));
        tools.addView(new Space(this), new LinearLayout.LayoutParams(dp(10), 1));
        Button scan = secondary("Reexaminar");
        scan.setOnClickListener(v -> scanLibrary());
        tools.addView(scan, new LinearLayout.LayoutParams(dp(150), dp(50)));
        col.addView(tools);

        String tree = VantaPrefs.treeUri(this);
        libraryStatus = text(tree.isEmpty() ? "Nenhuma pasta adicionada." : "Pasta vinculada • pronta para leitura", 12, MUTED, false);
        libraryStatus.setPadding(0, dp(12), 0, dp(12));
        col.addView(libraryStatus);

        librarySearch = new EditText(this);
        librarySearch.setHint("Buscar na biblioteca");
        librarySearch.setHintTextColor(Color.rgb(100, 114, 145));
        librarySearch.setTextColor(TEXT);
        librarySearch.setSingleLine(true);
        librarySearch.setTextSize(15);
        librarySearch.setPadding(dp(16), 0, dp(16), 0);
        librarySearch.setBackground(round(PANEL, STROKE, 15));
        librarySearch.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { renderLibrary(); }
            public void afterTextChanged(android.text.Editable s) {}
        });
        col.addView(librarySearch, new LinearLayout.LayoutParams(-1, dp(50)));

        libraryGrid = new GridLayout(this);
        libraryGrid.setColumnCount(libraryColumns());
        libraryGrid.setUseDefaultMargins(false);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, -2);
        glp.topMargin = dp(16);
        col.addView(libraryGrid, glp);

        s.addView(col);
        if (!tree.isEmpty()) scanLibrary(); else renderLibrary();
        return s;
    }

    private void scanLibrary() {
        String raw = VantaPrefs.treeUri(this);
        if (raw == null || raw.isEmpty()) {
            libraryGames = new ArrayList<>();
            if (libraryStatus != null) libraryStatus.setText("Adicione uma pasta de jogos.");
            renderLibrary();
            return;
        }
        if (libraryStatus != null) libraryStatus.setText("Examinando biblioteca…");
        final Uri treeUri = Uri.parse(raw);
        new Thread(() -> {
            List<VantaPrefs.GameEntry> found = new ArrayList<>();
            try {
                DocumentFile root = DocumentFile.fromTreeUri(this, treeUri);
                if (root != null) scanDir(root, 0, found);
                Collections.sort(found, Comparator.comparing(a -> a.name.toLowerCase(Locale.ROOT)));
            } catch (Exception ignored) {}
            runOnUiThread(() -> {
                libraryGames = found;
                if (libraryStatus != null) libraryStatus.setText(found.size() + " jogo(s) encontrado(s)");
                renderLibrary();
            });
        }).start();
    }

    private void scanDir(DocumentFile dir, int depth, List<VantaPrefs.GameEntry> out) {
        if (dir == null || depth > 5 || out.size() >= 400) return;
        DocumentFile[] files;
        try { files = dir.listFiles(); } catch (Exception e) { return; }
        for (DocumentFile f : files) {
            if (out.size() >= 400) break;
            if (f.isDirectory()) scanDir(f, depth + 1, out);
            else if (f.isFile() && supported(f.getName()))
                out.add(new VantaPrefs.GameEntry(cleanGameName(f.getName()), f.getUri().toString()));
        }
    }

    private boolean supported(String name) {
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".iso") || n.endsWith(".cso") || n.endsWith(".chd") || n.endsWith(".pbp") || n.endsWith(".elf");
    }

    private String cleanGameName(String name) {
        if (name == null) return "Jogo PSP";
        return name.replaceFirst("(?i)\\.(iso|cso|chd|pbp|elf)$", "");
    }

    private void renderLibrary() {
        if (libraryGrid == null) return;
        libraryGrid.removeAllViews();
        String q = librarySearch == null ? "" : librarySearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        List<VantaPrefs.GameEntry> filtered = new ArrayList<>();
        for (VantaPrefs.GameEntry g : libraryGames)
            if (q.isEmpty() || g.name.toLowerCase(Locale.ROOT).contains(q)) filtered.add(g);

        Collections.sort(filtered, (a, b) -> {
            boolean af = VantaPrefs.isFavorite(this, a.uri), bf = VantaPrefs.isFavorite(this, b.uri);
            if (af != bf) return af ? -1 : 1;
            return a.name.compareToIgnoreCase(b.name);
        });

        if (filtered.isEmpty()) {
            TextView empty = text(VantaPrefs.treeUri(this).isEmpty()
                ? "Adicione a pasta onde ficam seus jogos."
                : "Nenhum jogo encontrado com esse filtro.", 14, MUTED, false);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.columnSpec = GridLayout.spec(0, libraryColumns());
            lp.width = -1;
            lp.setMargins(0, dp(8), 0, 0);
            libraryGrid.addView(empty, lp);
            return;
        }

        int idx = 0;
        for (VantaPrefs.GameEntry game : filtered) {
            View tile = gameTile(game, true);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = dp(140);
            int cols = libraryColumns();
            lp.columnSpec = GridLayout.spec(idx % cols, 1f);
            lp.setMargins(idx % cols == 0 ? 0 : dp(6), dp(6), idx % cols == cols - 1 ? 0 : dp(6), dp(6));
            libraryGrid.addView(tile, lp);
            idx++;
        }
    }

    private View gameTile(VantaPrefs.GameEntry game, boolean libraryMode) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.BOTTOM);
        tile.setPadding(dp(16), dp(14), dp(16), dp(14));
        int hash = Math.abs(game.name.hashCode());
        int start = Color.rgb(22 + hash % 24, 29 + (hash / 7) % 28, 48 + (hash / 13) % 42);
        int end = hash % 2 == 0 ? Color.rgb(27, 43, 70) : Color.rgb(42, 29, 72);
        tile.setBackground(gradient(start, end, 20, 1, STROKE));
        tile.setFocusable(true);

        TextView badge = text(VantaPrefs.isFavorite(this, game.uri) ? "★  FAVORITO" : "PSP", 10,
            VantaPrefs.isFavorite(this, game.uri) ? CYAN : MUTED, true);
        badge.setLetterSpacing(0.08f);
        tile.addView(badge);
        tile.addView(new Space(this), new LinearLayout.LayoutParams(1, 0, 1f));
        TextView name = text(game.name, 16, TEXT, true);
        name.setMaxLines(2);
        tile.addView(name);
        TextView meta = text("Toque para jogar" + (libraryMode ? "  •  segure para favoritar" : ""), 10, MUTED, false);
        meta.setPadding(0, dp(5), 0, 0);
        tile.addView(meta);

        tile.setOnClickListener(v -> launch(game));
        tile.setOnLongClickListener(v -> {
            boolean fav = VantaPrefs.toggleFavorite(this, game.uri);
            Toast.makeText(this, fav ? "Adicionado aos favoritos" : "Removido dos favoritos", Toast.LENGTH_SHORT).show();
            if (libraryMode) renderLibrary(); else show(Page.HOME);
            return true;
        });
        return tile;
    }

    private View performancePage() {
        ScrollView s = pageScroller();
        LinearLayout col = pageColumn("VANTA ENGINE", "Performance sem adivinhação.",
            "Escolha o perfil antes de jogar ou ajuste durante a partida pelo VANTA Quick Tune.");

        HorizontalScrollView presetScroll = new HorizontalScrollView(this);
        presetScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        presetScroll.addView(presets);
        presets.addView(profileCard("Balanced", "2x • Vulkan", "Equilíbrio para a maioria dos jogos."), new LinearLayout.LayoutParams(dp(190), dp(118)));
        presets.addView(new Space(this), new LinearLayout.LayoutParams(dp(10), 1));
        presets.addView(profileCard("Turbo", "1x • Auto Skip", "Use em jogos pesados como Dante's Inferno."), new LinearLayout.LayoutParams(dp(190), dp(118)));
        presets.addView(new Space(this), new LinearLayout.LayoutParams(dp(10), 1));
        presets.addView(profileCard("Quality", "3x • Vulkan", "Mais nitidez quando houver folga de GPU."), new LinearLayout.LayoutParams(dp(190), dp(118)));
        presets.addView(new Space(this), new LinearLayout.LayoutParams(dp(10), 1));
        presets.addView(profileCard("Battery", "1x • Estável", "Sessões longas e menor carga térmica."), new LinearLayout.LayoutParams(dp(190), dp(118)));
        col.addView(presetScroll);

        TextView custom = text("Ajuste fino", 20, TEXT, true);
        custom.setPadding(0, dp(24), 0, dp(12));
        col.addView(custom);

        LinearLayout settings = card();
        settings.setOrientation(LinearLayout.VERTICAL);
        settings.setPadding(dp(20), dp(10), dp(20), dp(10));

        settings.addView(settingRow("Perfil VANTA", "Escolha um preset; depois ajuste itens individuais se quiser.",
            VantaPrefs.profile(this), v -> showChoiceDialog("Perfil VANTA",
                new String[]{"Balanced", "Turbo", "Quality", "Battery"},
                profileIndex(VantaPrefs.profile(this)), which -> {
                    String[] profiles = {"Balanced", "Turbo", "Quality", "Battery"};
                    VantaPrefs.applyPreset(this, profiles[which]);
                    show(Page.PERFORMANCE);
                })));
        settings.addView(divider());

        settings.addView(settingRow("Renderizador", "Vulkan costuma ser a melhor rota no Android.", backendName(), v ->
            showChoiceDialog("Renderizador",
                new String[]{"Vulkan — recomendado", "OpenGL — compatibilidade"},
                VantaPrefs.backend(this) == VantaPrefs.BACKEND_VULKAN ? 0 : 1, which -> {
                    VantaPrefs.setBackend(this, which == 0 ? VantaPrefs.BACKEND_VULKAN : VantaPrefs.BACKEND_OPENGL);
                    VantaPrefs.setProfile(this, "Custom");
                    show(Page.PERFORMANCE);
                })));
        settings.addView(divider());

        settings.addView(settingRow("Resolução interna", "1x é mais leve; 2x é o equilíbrio; 3x/4x exigem mais GPU.",
            VantaPrefs.resolution(this) + "x", v -> showChoiceDialog("Resolução interna",
                new String[]{"1x — máximo desempenho", "2x — equilibrado", "3x — qualidade", "4x — muito pesado"},
                VantaPrefs.resolution(this) - 1, which -> {
                    VantaPrefs.setResolution(this, which + 1);
                    VantaPrefs.setProfile(this, "Custom");
                    show(Page.PERFORMANCE);
                })));
        settings.addView(divider());

        settings.addView(settingRow("Frame skip", "Off preserva todos os quadros; 1–3 aliviam jogos pesados.",
            VantaPrefs.frameSkip(this) == 0 ? "Off" : String.valueOf(VantaPrefs.frameSkip(this)), v ->
            showChoiceDialog("Frame skip", new String[]{"Off", "1", "2", "3"},
                VantaPrefs.frameSkip(this), which -> {
                    VantaPrefs.setFrameSkip(this, which);
                    VantaPrefs.setProfile(this, "Custom");
                    show(Page.PERFORMANCE);
                })));
        settings.addView(divider());

        settings.addView(booleanChoiceRow("Auto frameskip", "Permite ao núcleo aliviar quadros quando necessário.",
            VantaPrefs.autoFrameSkip(this), value -> { VantaPrefs.setAutoFrameSkip(this, value); VantaPrefs.setProfile(this, "Custom"); }));
        settings.addView(divider());

        settings.addView(booleanChoiceRow("Fast memory", "Mantém o caminho rápido de memória do JIT.",
            VantaPrefs.fastMemory(this), value -> { VantaPrefs.setFastMemory(this, value); VantaPrefs.setProfile(this, "Custom"); }));
        settings.addView(divider());

        settings.addView(booleanChoiceRow("Hardware transform", "Usa a GPU para transformações gráficas.",
            VantaPrefs.hardwareTransform(this), value -> { VantaPrefs.setHardwareTransform(this, value); VantaPrefs.setProfile(this, "Custom"); }));
        settings.addView(divider());

        settings.addView(booleanChoiceRow("Sustained performance", "Pede ao Android desempenho sustentado em sessões longas.",
            VantaPrefs.sustainedPerformance(this), value -> { VantaPrefs.setSustainedPerformance(this, value); VantaPrefs.setProfile(this, "Custom"); }));

        col.addView(settings);
        TextView note = text("Durante o jogo, o menu VANTA agora é compacto: abra Desempenho, Visual ou Saves apenas quando precisar. Troca de renderizador continua valendo no próximo jogo.", 12, MUTED, false);
        note.setPadding(0, dp(12), 0, 0);
        col.addView(note);
        s.addView(col);
        return s;
    }

    private View visualPage() {
        ScrollView s = pageScroller();
        LinearLayout col = pageColumn("VANTA VISUAL LAB", "Imagem do seu jeito.",
            "Todos os recursos são manuais. Você escolhe nitidez, filtros e upscale sem mexer no perfil de desempenho.");

        LinearLayout summary = card();
        summary.setOrientation(LinearLayout.HORIZONTAL);
        summary.setPadding(dp(18), dp(14), dp(18), dp(14));
        summary.addView(statCard("RESOLUÇÃO", VantaPrefs.resolution(this) + "x", "render interno"), weightMargin(1f, 0, 0, dp(6), 0));
        summary.addView(statCard("ANISO", anisotropyName(), "texturas em ângulo"), weightMargin(1f, dp(6), 0, dp(6), 0));
        summary.addView(statCard("PÓS", postShaderName(), "shader ativo"), weightMargin(1f, dp(6), 0, 0, 0));
        col.addView(summary);

        TextView quality = text("Qualidade de imagem", 20, TEXT, true);
        quality.setPadding(0, dp(24), 0, dp(12));
        col.addView(quality);

        LinearLayout settings = card();
        settings.setOrientation(LinearLayout.VERTICAL);
        settings.setPadding(dp(20), dp(10), dp(20), dp(10));

        settings.addView(settingRow("Resolução interna", "Upscale geométrico do jogo. 2x costuma ser o melhor equilíbrio.",
            VantaPrefs.resolution(this) + "x", v -> showChoiceDialog("Resolução interna",
                new String[]{"1x — original", "2x — nítido", "3x — alta qualidade", "4x — ultra"},
                VantaPrefs.resolution(this) - 1, which -> {
                    VantaPrefs.setResolution(this, which + 1);
                    VantaPrefs.setProfile(this, "Custom");
                    show(Page.VISUAL);
                })));
        settings.addView(divider());

        settings.addView(settingRow("Filtro anisotrópico", "Melhora chão, paredes e texturas vistas em ângulo.",
            anisotropyName(), v -> showChoiceDialog("Filtro anisotrópico",
                new String[]{"Off", "2x", "4x", "8x", "16x"}, VantaPrefs.anisotropy(this), which -> {
                    VantaPrefs.setAnisotropy(this, which);
                    show(Page.VISUAL);
                })));
        settings.addView(divider());

        settings.addView(settingRow("Filtro de textura", "Controle direto do modo de filtragem do núcleo.",
            textureFilteringName(), v -> showChoiceDialog("Filtro de textura",
                new String[]{"Auto", "Nearest — pixelado", "Linear — suave", "Auto Max Quality"},
                VantaPrefs.textureFiltering(this) - 1, which -> {
                    VantaPrefs.setTextureFiltering(this, which + 1);
                    show(Page.VISUAL);
                })));
        settings.addView(divider());

        settings.addView(booleanChoiceRowForPage(Page.VISUAL, "Smart 2D filtering", "Evita borrar elementos 2D quando possível.",
            VantaPrefs.smart2DFiltering(this), value -> VantaPrefs.setSmart2DFiltering(this, value)));
        settings.addView(divider());

        settings.addView(settingRow("Upscale de texturas", "Processa texturas antes de desenhar. Pode pesar em jogos grandes.",
            textureScaleLevelName(), v -> showChoiceDialog("Upscale de texturas",
                new String[]{"Off", "2x", "3x"}, VantaPrefs.textureScaleLevel(this) - 1, which -> {
                    VantaPrefs.setTextureScaleLevel(this, which + 1);
                    show(Page.VISUAL);
                })));
        settings.addView(divider());

        settings.addView(settingRow("Algoritmo de upscale", "Só é usado quando o upscale de texturas está ligado.",
            textureScaleTypeName(), v -> showChoiceDialog("Algoritmo de upscale",
                new String[]{"xBRZ", "Hybrid", "Bicubic", "Hybrid + Bicubic"}, VantaPrefs.textureScaleType(this), which -> {
                    VantaPrefs.setTextureScaleType(this, which);
                    show(Page.VISUAL);
                })));
        settings.addView(divider());

        settings.addView(booleanChoiceRowForPage(Page.VISUAL, "Deposterize", "Reduz faixas de cor em texturas ampliadas.",
            VantaPrefs.deposterize(this), value -> VantaPrefs.setDeposterize(this, value)));
        settings.addView(divider());

        settings.addView(settingRow("Pós-processamento", "Shader aplicado à imagem final. Sharpen e FSR-RCAS são boas opções leves.",
            postShaderName(), v -> showChoiceDialog("Pós-processamento",
                new String[]{"Off", "Sharpen", "FXAA", "Natural Colors", "PSP Color", "FSR-RCAS", "Bloom"},
                VantaPrefs.postShader(this), which -> {
                    VantaPrefs.setPostShader(this, which);
                    show(Page.VISUAL);
                })));

        col.addView(settings);
        TextView warning = text("Dica: resolução interna + anisotrópico costumam dar o maior ganho visual. Upscale de texturas e Bloom são os mais propensos a custar desempenho.", 12, MUTED, false);
        warning.setPadding(0, dp(12), 0, 0);
        col.addView(warning);
        s.addView(col);
        return s;
    }

    private String anisotropyName() {
        String[] values = {"Off", "2x", "4x", "8x", "16x"};
        return values[VantaPrefs.anisotropy(this)];
    }

    private String textureFilteringName() {
        String[] values = {"Auto", "Nearest", "Linear", "Auto Max"};
        return values[VantaPrefs.textureFiltering(this) - 1];
    }

    private String textureScaleLevelName() {
        String[] values = {"Off", "2x", "3x"};
        return values[VantaPrefs.textureScaleLevel(this) - 1];
    }

    private String textureScaleTypeName() {
        String[] values = {"xBRZ", "Hybrid", "Bicubic", "Hybrid + Bicubic"};
        return values[VantaPrefs.textureScaleType(this)];
    }

    private String postShaderName() {
        String[] values = {"Off", "Sharpen", "FXAA", "Natural", "PSP Color", "FSR-RCAS", "Bloom"};
        return values[VantaPrefs.postShader(this)];
    }

    private View profileCard(String name, String spec, String description) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        boolean active = VantaPrefs.profile(this).equals(name);
        if (active) c.setBackground(gradient(Color.rgb(16, 39, 53), Color.rgb(29, 24, 66), 18, 1, CYAN));
        c.addView(text(name, 17, TEXT, true));
        TextView sp = text(spec, 11, active ? CYAN : BLUE, true);
        sp.setPadding(0, dp(6), 0, dp(8));
        c.addView(sp);
        TextView d = text(description, 11, MUTED, false);
        d.setMaxLines(2);
        c.addView(d);
        c.setFocusable(true);
        c.setOnClickListener(v -> {
            VantaPrefs.applyPreset(this, name);
            Toast.makeText(this, "Perfil " + name + " ativado", Toast.LENGTH_SHORT).show();
            show(Page.PERFORMANCE);
        });
        return c;
    }

    private File vantaMemoryCardRoot() {
        File external = getExternalFilesDir(null);
        return external != null ? external : getFilesDir();
    }

    private boolean ensureVantaMemoryCard() {
        File root = vantaMemoryCardRoot();
        if (root == null) return false;
        File savedata = new File(root, "PSP/SAVEDATA");
        File states = new File(root, "PSP/PPSSPP_STATE");
        File system = new File(root, "PSP/SYSTEM");
        boolean ok = savedata.exists() || savedata.mkdirs();
        ok = (states.exists() || states.mkdirs()) && ok;
        ok = (system.exists() || system.mkdirs()) && ok;
        return ok;
    }

    private int countMemoryCardSaves() {
        File dir = new File(vantaMemoryCardRoot(), "PSP/SAVEDATA");
        File[] files = dir.listFiles();
        if (files == null) return 0;
        int count = 0;
        for (File f : files) if (f.isDirectory()) count++;
        return count;
    }

    private int countSaveStates() {
        File dir = new File(vantaMemoryCardRoot(), "PSP/PPSSPP_STATE");
        File[] files = dir.listFiles();
        if (files == null) return 0;
        int count = 0;
        for (File f : files) {
            if (f.isFile() && f.getName().toLowerCase(Locale.ROOT).endsWith(".ppst")) count++;
        }
        return count;
    }

    private View savesPage() {
        ScrollView s = pageScroller();
        LinearLayout col = pageColumn("SAVE CENTER", "Memory Card e estados, sem mistério.",
            "O VANTA separa o save normal do PSP dos Save States rápidos. Os dois continuam compatíveis com o núcleo.");

        LinearLayout memory = card();
        memory.setOrientation(LinearLayout.VERTICAL);
        memory.setPadding(dp(20), dp(18), dp(20), dp(18));
        memory.addView(text("Memory Card virtual", 19, TEXT, true));
        TextView memBody = text("Os saves feitos pelo próprio jogo ficam no Memory Card virtual (PSP/SAVEDATA). "
            + "Eles são diferentes de Save State e continuam existindo mesmo quando você fecha o jogo.", 12, MUTED, false);
        memBody.setPadding(0, dp(8), 0, dp(12));
        memory.addView(memBody);
        boolean memReady = ensureVantaMemoryCard();
        TextView active = text(memReady ? "STATUS  •  PRONTO PARA GRAVAR" : "STATUS  •  ERRO DE ARMAZENAMENTO",
            11, memReady ? GREEN : Color.rgb(255, 120, 120), true);
        memory.addView(active);
        TextView memStats = text("Saves do jogo: " + countMemoryCardSaves()
            + "   •   Save States: " + countSaveStates(), 11, CYAN, true);
        memStats.setPadding(0, dp(8), 0, 0);
        memory.addView(memStats);
        TextView memPath = text("Local: " + vantaMemoryCardRoot().getAbsolutePath() + "/PSP", 10, MUTED, false);
        memPath.setPadding(0, dp(6), 0, 0);
        memory.addView(memPath);
        col.addView(memory);

        LinearLayout states = card();
        states.setOrientation(LinearLayout.VERTICAL);
        states.setPadding(dp(20), dp(18), dp(20), dp(18));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = dp(14);
        col.addView(states, slp);
        states.addView(text("Save States VANTA", 19, TEXT, true));
        TextView stateBody = text("Durante qualquer jogo: Voltar → VANTA SAVE HUB. Escolha o slot em um submenu e use Salvar ou Carregar. "
            + "A R5 expõe 5 slots rápidos e um acesso direto ao gerenciador do Memory Card.", 12, MUTED, false);
        stateBody.setPadding(0, dp(8), 0, dp(14));
        states.addView(stateBody);

        VantaPrefs.GameEntry last = VantaPrefs.lastGame(this);
        Button openLast = primary(last == null ? "Abra um jogo primeiro" : "Abrir último jogo e acessar Save Hub");
        openLast.setEnabled(last != null);
        openLast.setAlpha(last == null ? 0.45f : 1f);
        openLast.setOnClickListener(v -> { VantaPrefs.GameEntry g = VantaPrefs.lastGame(this); if (g != null) launch(g); });
        states.addView(openLast, new LinearLayout.LayoutParams(-1, dp(50)));

        TextView tip = text("Dica: save do jogo = Memory Card. Save State = fotografia instantânea da emulação. Use os dois.", 11, CYAN, true);
        tip.setPadding(0, dp(14), 0, 0);
        states.addView(tip);

        s.addView(col);
        return s;
    }

    private View controlsPage() {
        ScrollView s = pageScroller();
        LinearLayout col = pageColumn("INPUT LAB", "Controle primeiro.",
            "Diagnóstico dos controles conectados. A navegação do VANTA responde a D-pad e botão A.");

        List<InputDevice> pads = connectedPads();
        LinearLayout devices = card();
        devices.setOrientation(LinearLayout.VERTICAL);
        devices.setPadding(dp(20), dp(18), dp(20), dp(18));
        if (pads.isEmpty()) {
            devices.addView(text("Nenhum gamepad detectado agora.", 15, MUTED, false));
        } else {
            for (int i = 0; i < pads.size(); i++) {
                InputDevice d = pads.get(i);
                devices.addView(text(d.getName(), 16, TEXT, true));
                devices.addView(text("ID " + d.getId() + "  •  vendor " + d.getVendorId() + "  •  product " + d.getProductId(), 11, MUTED, false));
                if (i != pads.size() - 1) {
                    View div = divider();
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
                    lp.setMargins(0, dp(12), 0, dp(12));
                    devices.addView(div, lp);
                }
            }
        }
        col.addView(devices);

        TextView tt = text("Teste ao vivo", 20, TEXT, true);
        tt.setPadding(0, dp(22), 0, dp(10));
        col.addView(tt);
        inputMonitor = text("Pressione um botão ou mova um analógico.", 15, CYAN, true);
        inputMonitor.setPadding(dp(18), dp(18), dp(18), dp(18));
        inputMonitor.setBackground(round(PANEL, STROKE, 18));
        col.addView(inputMonitor);
        TextView hint = text("A = confirmar  •  B = voltar ao início  •  START = continuar último jogo", 12, MUTED, false);
        hint.setPadding(0, dp(12), 0, 0);
        col.addView(hint);

        s.addView(col);
        return s;
    }

    private View aboutPage() {
        ScrollView s = pageScroller();
        LinearLayout col = pageColumn("SISTEMA", "O que está por baixo.",
            "Informações do build e do aparelho para facilitar diagnóstico e otimização.");

        LinearLayout info = card();
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(20), dp(18), dp(20), dp(18));
        addInfo(info, "VANTA", "Unified build");
        addInfo(info, "Core", "PPSSPP 1.20.4");
        addInfo(info, "ABI", Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "desconhecida");
        addInfo(info, "Aparelho", Build.MANUFACTURER + " " + Build.MODEL);
        addInfo(info, "Hardware", Build.HARDWARE + " / " + Build.BOARD);
        addInfo(info, "Android", Build.VERSION.RELEASE + " • API " + Build.VERSION.SDK_INT);
        addInfo(info, "Perfil", VantaPrefs.profile(this) + " • " + backendName() + " • " + VantaPrefs.resolution(this) + "x");
        col.addView(info);

        LinearLayout legal = card();
        legal.setOrientation(LinearLayout.VERTICAL);
        legal.setPadding(dp(20), dp(18), dp(20), dp(18));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, -2);
        llp.topMargin = dp(16);
        col.addView(legal, llp);
        legal.addView(text("Projeto e licenças", 17, TEXT, true));
        TextView body = text("VANTA é uma distribuição/interface Android construída sobre o núcleo open-source PPSSPP. "
            + "PPSSPP permanece creditado e sujeito à GPL. O aplicativo não inclui jogos, firmware ou conteúdo protegido.", 12, MUTED, false);
        body.setPadding(0, dp(8), 0, dp(14));
        legal.addView(body);
        Button reset = secondary("Redefinir preferências VANTA");
        reset.setOnClickListener(v -> {
            VantaPrefs.reset(this);
            Toast.makeText(this, "Preferências restauradas", Toast.LENGTH_SHORT).show();
            show(Page.HOME);
        });
        legal.addView(reset, new LinearLayout.LayoutParams(dp(260), dp(50)));
        s.addView(col);
        return s;
    }

    private void addInfo(LinearLayout parent, String key, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView k = text(key, 13, MUTED, true);
        TextView v = text(value, 13, TEXT, false);
        v.setGravity(Gravity.RIGHT);
        row.addView(k, new LinearLayout.LayoutParams(0, dp(38), 1f));
        row.addView(v, new LinearLayout.LayoutParams(0, dp(38), 2f));
        parent.addView(row);
    }

    private View settingRow(String title, String subtitle, String value, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(12), 0, dp(12));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1f));
        copy.addView(text(title, 15, TEXT, true));
        TextView s = text(subtitle, 11, MUTED, false);
        s.setPadding(0, dp(4), dp(14), 0);
        copy.addView(s);
        Button valueButton = secondary(value);
        valueButton.setOnClickListener(click);
        row.addView(valueButton, new LinearLayout.LayoutParams(dp(140), dp(46)));
        return row;
    }

    private interface ChoiceCallback { void selected(int which); }

    private void showChoiceDialog(String title, String[] options, int checked, ChoiceCallback callback) {
        int safeChecked = Math.max(0, Math.min(options.length - 1, checked));
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(options, safeChecked, null)
            .setNegativeButton("Cancelar", null)
            .create();
        dialog.setOnShowListener(ignored -> {
            dialog.getListView().setOnItemClickListener((parent, view, position, id) -> {
                callback.selected(position);
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private int profileIndex(String profile) {
        if ("Turbo".equals(profile)) return 1;
        if ("Quality".equals(profile)) return 2;
        if ("Battery".equals(profile)) return 3;
        return 0;
    }

    private View booleanChoiceRowForPage(Page page, String title, String subtitle, boolean value, ToggleCallback callback) {
        return settingRow(title, subtitle, value ? "Ligado" : "Desligado", v ->
            showChoiceDialog(title, new String[]{"Ligado", "Desligado"}, value ? 0 : 1, which -> {
                callback.changed(which == 0);
                show(page);
            }));
    }

    private View booleanChoiceRow(String title, String subtitle, boolean value, ToggleCallback callback) {
        return settingRow(title, subtitle, value ? "Ligado" : "Desligado", v ->
            showChoiceDialog(title, new String[]{"Ligado", "Desligado"}, value ? 0 : 1, which -> {
                callback.changed(which == 0);
                show(Page.PERFORMANCE);
            }));
    }

    private interface ToggleCallback { void changed(boolean value); }

    private View toggleRow(String title, String subtitle, boolean initial, ToggleCallback callback) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(12), 0, dp(12));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1f));
        copy.addView(text(title, 15, TEXT, true));
        TextView s = text(subtitle, 11, MUTED, false);
        s.setPadding(0, dp(4), dp(14), 0);
        copy.addView(s);
        Button toggle = secondary(initial ? "ATIVO" : "DESLIGADO");
        toggle.setTextColor(initial ? GREEN : MUTED);
        toggle.setOnClickListener(v -> {
            boolean next = !toggle.getText().toString().equals("ATIVO");
            toggle.setText(next ? "ATIVO" : "DESLIGADO");
            toggle.setTextColor(next ? GREEN : MUTED);
            callback.changed(next);
        });
        row.addView(toggle, new LinearLayout.LayoutParams(dp(140), dp(46)));
        return row;
    }

    private View statCard(String label, String value, String sub) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.addView(text(label, 10, MUTED, true));
        TextView v = text(value, 19, TEXT, true);
        v.setPadding(0, dp(6), 0, dp(3));
        c.addView(v);
        c.addView(text(sub, 11, BLUE, true));
        return c;
    }

    private LinearLayout card() { LinearLayout c = new LinearLayout(this); c.setBackground(round(PANEL, STROKE, 20)); return c; }

    private Button primary(String label) {
        Button b = baseButton(label);
        b.setTextColor(Color.rgb(7, 12, 20));
        b.setBackground(gradient(CYAN, Color.rgb(138, 188, 255), 16, 0, 0));
        return b;
    }

    private Button secondary(String label) {
        Button b = baseButton(label);
        b.setTextColor(TEXT);
        b.setBackground(round(PANEL_2, STROKE, 16));
        return b;
    }

    private Button baseButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(13);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setFocusable(true);
        return b;
    }

    private TextView chip(String value) {
        TextView c = text(value, 11, CYAN, true);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(13), dp(8), dp(13), dp(8));
        c.setBackground(round(Color.rgb(12, 33, 43), Color.rgb(43, 103, 116), 999));
        return c;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.rgb(35, 45, 68));
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return v;
    }

    private GradientDrawable round(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private GradientDrawable gradient(int start, int end, int radius, int strokeWidth, int stroke) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{start, end});
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), stroke);
        return d;
    }

    private LinearLayout.LayoutParams matchWrapMargin(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(l, t, r, b);
        return p;
    }

    private LinearLayout.LayoutParams weightMargin(float weight, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, weight);
        p.setMargins(l, t, r, b);
        return p;
    }

    private boolean isCompact() {
        float widthDp = getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density;
        return widthDp < 900f;
    }

    private int libraryColumns() {
        return isCompact() ? 2 : 3;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private String backendName() { return VantaPrefs.backend(this) == VantaPrefs.BACKEND_VULKAN ? "Vulkan" : "OpenGL"; }

    private void pickGame() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_PICK_GAME);
    }

    private void pickTree() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i, REQ_PICK_TREE);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (request == REQ_PICK_TREE) {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
            VantaPrefs.setTreeUri(this, uri.toString());
            show(Page.LIBRARY);
            return;
        }

        if (request == REQ_PICK_GAME) {
            int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
            String name = displayName(uri);
            if (!supported(name)) Toast.makeText(this, "Formato não reconhecido como jogo PSP. Você ainda pode tentar abrir.", Toast.LENGTH_LONG).show();
            launch(new VantaPrefs.GameEntry(cleanGameName(name), uri.toString()));
        }
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        String s = uri.getLastPathSegment();
        return s == null ? "Jogo PSP" : s;
    }

    private void launch(VantaPrefs.GameEntry game) {
        VantaPrefs.setLastGame(this, game);
        Intent i = new Intent(this, PpssppActivity.class);
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse(game.uri));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.putExtra("vanta_managed", true);
        i.putExtra("vanta_profile", VantaPrefs.profile(this));
        i.putExtra("vanta_backend", VantaPrefs.backend(this));
        i.putExtra("vanta_resolution", VantaPrefs.resolution(this));
        i.putExtra("vanta_frameskip", VantaPrefs.frameSkip(this));
        i.putExtra("vanta_auto_frameskip", VantaPrefs.autoFrameSkip(this));
        i.putExtra("vanta_fast_memory", VantaPrefs.fastMemory(this));
        i.putExtra("vanta_hardware_transform", VantaPrefs.hardwareTransform(this));
        i.putExtra("vanta_sustained_performance", VantaPrefs.sustainedPerformance(this));
        i.putExtra("vanta_anisotropy", VantaPrefs.anisotropy(this));
        i.putExtra("vanta_texture_filtering", VantaPrefs.textureFiltering(this));
        i.putExtra("vanta_smart_2d_filtering", VantaPrefs.smart2DFiltering(this));
        i.putExtra("vanta_texture_scale_level", VantaPrefs.textureScaleLevel(this));
        i.putExtra("vanta_texture_scale_type", VantaPrefs.textureScaleType(this));
        i.putExtra("vanta_deposterize", VantaPrefs.deposterize(this));
        i.putExtra("vanta_post_shader", VantaPrefs.postShader(this));
        startActivity(i);
    }

    private List<InputDevice> connectedPads() {
        List<InputDevice> out = new ArrayList<>();
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null) continue;
            int s = d.getSources();
            if ((s & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (s & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) out.add(d);
        }
        return out;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (currentPage == Page.CONTROLS && inputMonitor != null)
            inputMonitor.setText("KEY " + e.getKeyCode() + "  •  " + KeyEvent.keyCodeToString(e.getKeyCode())
                + "  •  " + (e.getAction() == KeyEvent.ACTION_DOWN ? "DOWN" : "UP"));
        if (e.getAction() == KeyEvent.ACTION_UP) {
            if (e.getKeyCode() == KeyEvent.KEYCODE_BUTTON_A) {
                View f = getCurrentFocus();
                if (f != null && f.isClickable()) { f.performClick(); return true; }
            } else if (e.getKeyCode() == KeyEvent.KEYCODE_BUTTON_B) {
                if (currentPage != Page.HOME) { show(Page.HOME); return true; }
            } else if (e.getKeyCode() == KeyEvent.KEYCODE_BUTTON_START) {
                VantaPrefs.GameEntry g = VantaPrefs.lastGame(this);
                if (g != null) { launch(g); return true; }
            }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent e) {
        if (currentPage == Page.CONTROLS && inputMonitor != null
            && (e.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
            float x = e.getAxisValue(MotionEvent.AXIS_X), y = e.getAxisValue(MotionEvent.AXIS_Y);
            float rx = e.getAxisValue(MotionEvent.AXIS_Z), ry = e.getAxisValue(MotionEvent.AXIS_RZ);
            inputMonitor.setText(String.format(Locale.ROOT, "LX %.2f  LY %.2f  •  RX %.2f  RY %.2f", x, y, rx, ry));
        }
        return super.onGenericMotionEvent(e);
    }
}
