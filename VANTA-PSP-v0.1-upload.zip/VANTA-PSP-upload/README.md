# VANTA PSP

VANTA PSP is an Android-focused PSP emulator distribution built around the open-source PPSSPP engine, with a distinct launcher, Android build pipeline, controller-first UX and device-focused performance work.

## Bootstrap status

- Engine pin: PPSSPP `v1.20.4`
- Target: Android ARM64
- Application ID: `com.vantapsp.emulator`
- Build flavor: `normalOptimized`
- Launcher: custom VANTA Android launcher
- Supported game selection: ISO, CSO, CHD, PBP and other formats supported by the PPSSPP core
- CI output: APK + SHA-256 checksum

## Why this repository is small

Instead of copying the full PPSSPP tree, GitHub Actions clones the pinned upstream version and applies the VANTA overlay and patches. This makes upstream changes auditable and keeps VANTA-specific work isolated.

## Build on GitHub

1. Open **Actions**.
2. Open **Build VANTA PSP**.
3. Choose **Run workflow**.
4. Download the `VANTA-PSP-arm64` artifact.

The artifact contains the APK and a SHA-256 checksum.

## Project direction

The initial milestone is a reliable, installable ARM64 Android build with a VANTA launcher. Later milestones add per-game profiles, device-aware AutoTune, shader-cache management, frame pacing instrumentation, thermal-aware presets and deeper VANTA theming.

## Legal

PPSSPP is free and open-source software. VANTA PSP is not affiliated with Sony Interactive Entertainment. This project does not include games, firmware, BIOS files, decryption keys or copyrighted game data. Users are responsible for using legally obtained game dumps.

Any distributed PPSSPP-derived binary and modifications must comply with the upstream PPSSPP license.
