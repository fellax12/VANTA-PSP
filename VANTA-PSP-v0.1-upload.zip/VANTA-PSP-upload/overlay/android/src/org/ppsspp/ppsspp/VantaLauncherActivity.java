package org.ppsspp.ppsspp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;

public class VantaLauncherActivity extends Activity {
    private static final int PICK_GAME = 9001;
    private static final String PREFS = "vanta_launcher";
    private static final String LAST_GAME_URI = "last_game_uri";

    private LinearLayout root;
    private TextView recentText;
    private Button lastGameButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUi();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable panel(int fill, int stroke, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp((int) radiusDp));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(primary ? Color.BLACK : Color.WHITE);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setPadding(dp(20), dp(13), dp(20), dp(13));
        b.setBackground(panel(
                primary ? Color.rgb(245, 245, 245) : Color.rgb(22, 22, 25),
                primary ? Color.WHITE : Color.rgb(65, 65, 72),
                14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(lp);
        return b;
    }

    private void buildUi() {
        int bg = Color.rgb(7, 7, 9);
        int muted = Color.rgb(157, 157, 166);
        int accent = Color.rgb(235, 235, 240);

        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(bg);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(42), dp(28), dp(42), dp(28));
        scroller.addView(root, new ScrollView.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout titleBlock = new LinearLayout(this);
        titleBlock.setOrientation(LinearLayout.VERTICAL);
        header.addView(titleBlock, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView title = text("VANTA", 30, Color.WHITE, true);
        title.setLetterSpacing(0.12f);
        titleBlock.addView(title);

        TextView subtitle = text("PSP  /  OBSIDIAN BUILD", 12, muted, true);
        subtitle.setLetterSpacing(0.08f);
        titleBlock.addView(subtitle);

        TextView badge = text("ARM64  •  OPTIMIZED", 12, accent, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(16), dp(9), dp(16), dp(9));
        badge.setBackground(panel(Color.rgb(19, 19, 23), Color.rgb(74, 74, 84), 18));
        header.addView(badge);

        Space topGap = new Space(this);
        root.addView(topGap, new LinearLayout.LayoutParams(1, dp(24)));

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setPadding(dp(24), dp(22), dp(24), dp(22));
        hero.setBackground(panel(Color.rgb(13, 13, 16), Color.rgb(46, 46, 54), 22));
        root.addView(hero, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        hero.addView(copy, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView heroTitle = text("Escolha o jogo. O resto é ruído.", 23, Color.WHITE, true);
        copy.addView(heroTitle);

        TextView heroBody = text("Launcher VANTA ligado ao núcleo PPSSPP v1.20.4. O primeiro build prioriza estabilidade, ARM64 e uma interface rápida para controle.", 14, muted, false);
        heroBody.setPadding(0, dp(8), dp(24), 0);
        copy.addView(heroBody);

        TextView core = text("CORE\n1.20.4", 13, Color.WHITE, true);
        core.setGravity(Gravity.CENTER);
        core.setPadding(dp(18), dp(14), dp(18), dp(14));
        core.setBackground(panel(Color.rgb(27, 27, 32), Color.rgb(70, 70, 80), 18));
        hero.addView(core, new LinearLayout.LayoutParams(dp(118), dp(80)));

        Space midGap = new Space(this);
        root.addView(midGap, new LinearLayout.LayoutParams(1, dp(18)));

        LinearLayout columns = new LinearLayout(this);
        columns.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(columns, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setPadding(0, 0, dp(10), 0);
        columns.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));

        Button choose = button("Jogar / escolher arquivo", true);
        choose.setOnClickListener(v -> pickGame());
        left.addView(choose);

        lastGameButton = button("Continuar último jogo", false);
        lastGameButton.setOnClickListener(v -> launchLastGame());
        left.addView(lastGameButton);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(dp(10), 0, 0, 0);
        columns.addView(right, new LinearLayout.LayoutParams(0, -2, 1f));

        Button coreMenu = button("Abrir biblioteca e ajustes do núcleo", false);
        coreMenu.setOnClickListener(v -> launchCore(null));
        right.addView(coreMenu);

        Button appInfo = button("Informações do aplicativo", false);
        appInfo.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        right.addView(appInfo);

        Space bottomGap = new Space(this);
        root.addView(bottomGap, new LinearLayout.LayoutParams(1, dp(18)));

        recentText = text("", 12, muted, false);
        root.addView(recentText);
        refreshRecent();

        choose.requestFocus();
        setContentView(scroller);
    }

    private void refreshRecent() {
        String last = getSharedPreferences(PREFS, MODE_PRIVATE).getString(LAST_GAME_URI, null);
        if (last == null || last.isEmpty()) {
            recentText.setText("Nenhum jogo recente ainda.");
            lastGameButton.setEnabled(false);
            lastGameButton.setAlpha(0.45f);
        } else {
            Uri uri = Uri.parse(last);
            String display = uri.getLastPathSegment();
            recentText.setText("Último jogo: " + (display == null ? last : display));
            lastGameButton.setEnabled(true);
            lastGameButton.setAlpha(1f);
        }
    }

    private void pickGame() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "application/octet-stream",
                "application/x-iso9660-image",
                "application/x-cd-image"
        });
        startActivityForResult(i, PICK_GAME);
    }

    private void launchLastGame() {
        String last = getSharedPreferences(PREFS, MODE_PRIVATE).getString(LAST_GAME_URI, null);
        if (last != null) launchCore(Uri.parse(last));
    }

    private void launchCore(Uri gameUri) {
        Intent i = new Intent(this, PpssppActivity.class);
        if (gameUri != null) {
            i.setAction(Intent.ACTION_VIEW);
            i.setDataAndType(gameUri, "*/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        startActivity(i);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_GAME || resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putString(LAST_GAME_URI, uri.toString()).apply();
        refreshRecent();
        launchCore(uri);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_UP && event.getKeyCode() == KeyEvent.KEYCODE_BUTTON_A) {
            View focused = getCurrentFocus();
            if (focused != null && focused.isClickable()) {
                focused.performClick();
                return true;
            }
        }
        if (event.getAction() == KeyEvent.ACTION_UP && event.getKeyCode() == KeyEvent.KEYCODE_BUTTON_START) {
            launchCore(null);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
}
