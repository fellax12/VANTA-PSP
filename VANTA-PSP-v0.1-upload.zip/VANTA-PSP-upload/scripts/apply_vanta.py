#!/usr/bin/env python3
from __future__ import annotations

import shutil
import sys
from pathlib import Path


APP_ID = "com.vantapsp.emulator"
APP_NAME = "VANTA PSP"


def fail(message: str) -> None:
    raise SystemExit(f"VANTA patch error: {message}")


def replace_required(text: str, old: str, new: str, *, count: int = -1, label: str = "patch") -> str:
    hits = text.count(old)
    if hits == 0:
        fail(f"upstream changed; could not find required {label}")
    if count >= 0 and hits < count:
        fail(f"upstream changed; expected at least {count} occurrence(s) for {label}, found {hits}")
    return text.replace(old, new, count)


def patch_gradle(root: Path) -> None:
    path = root / "android" / "build.gradle.kts"
    text = path.read_text(encoding="utf-8")

    text = replace_required(
        text,
        'applicationId = "org.ppsspp.ppsspp"',
        f'applicationId = "{APP_ID}"',
        label="Android application id",
    )

    # VANTA bootstrap is ARM64-first. Replace only the first normal-flavor ABI list.
    text = replace_required(
        text,
        'abiFilters.addAll(listOf("armeabi-v7a", "arm64-v8a", "x86_64"))',
        'abiFilters.add("arm64-v8a")',
        count=1,
        label="normal flavor ABI filters",
    )

    optimized_old = '''create("optimized") {
\t\t\tisMinifyEnabled = false
\t\t\tisJniDebuggable = true
\t\t\tsigningConfig = signingConfigs.getByName("debug")
\t\t}'''
    optimized_new = '''create("optimized") {
\t\t\tisMinifyEnabled = false
\t\t\tisJniDebuggable = false
\t\t\tsigningConfig = signingConfigs.getByName("debug")
\t\t}'''
    text = replace_required(text, optimized_old, optimized_new, count=1, label="optimized build type")

    path.write_text(text, encoding="utf-8")


def patch_strings(root: Path) -> None:
    path = root / "android" / "res" / "values" / "strings.xml"
    text = path.read_text(encoding="utf-8")
    text = replace_required(text, '<string name="app_name">PPSSPP</string>', f'<string name="app_name">{APP_NAME}</string>', count=1, label="app name")
    text = replace_required(text, '<string name="shortcut_name">PPSSPP game</string>', '<string name="shortcut_name">VANTA game</string>', count=1, label="shortcut name")
    path.write_text(text, encoding="utf-8")


def patch_manifest(root: Path) -> None:
    path = root / "android" / "AndroidManifest.xml"
    text = path.read_text(encoding="utf-8")

    original_launcher_filter = '''            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
'''
    text = replace_required(text, original_launcher_filter, "", count=1, label="PPSSPP launcher intent filter")

    marker = '''        <activity
            android:name=".PpssppActivity"'''
    vanta_activity = '''        <activity
            android:name=".VantaLauncherActivity"
            android:configChanges="locale|keyboard|keyboardHidden|navigation|orientation|screenSize|uiMode"
            android:screenOrientation="landscape"
            android:theme="@style/ppsspp_style"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".PpssppActivity"'''
    text = replace_required(text, marker, vanta_activity, count=1, label="PpssppActivity declaration")
    path.write_text(text, encoding="utf-8")


def copy_overlay(project_root: Path, upstream_root: Path) -> None:
    overlay_root = project_root / "overlay"
    if not overlay_root.exists():
        fail("overlay directory is missing")
    for src in overlay_root.rglob("*"):
        if src.is_dir():
            continue
        rel = src.relative_to(overlay_root)
        dst = upstream_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def write_marker(root: Path) -> None:
    marker = root / "assets" / "vanta_build.txt"
    marker.write_text(
        "VANTA PSP bootstrap\n"
        "Engine: PPSSPP v1.20.4\n"
        "Target: Android ARM64 normalOptimized\n",
        encoding="utf-8",
    )


def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: apply_vanta.py <ppsspp-source-directory>")

    upstream_root = Path(sys.argv[1]).resolve()
    project_root = Path(__file__).resolve().parent.parent

    required = [
        upstream_root / "android" / "build.gradle.kts",
        upstream_root / "android" / "AndroidManifest.xml",
        upstream_root / "android" / "res" / "values" / "strings.xml",
        upstream_root / "CMakeLists.txt",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        fail("not a compatible PPSSPP source tree; missing: " + ", ".join(missing))

    patch_gradle(upstream_root)
    patch_strings(upstream_root)
    patch_manifest(upstream_root)
    copy_overlay(project_root, upstream_root)
    write_marker(upstream_root)
    print("VANTA layer applied successfully.")


if __name__ == "__main__":
    main()
