# VANTA architecture

## Layer 1 — Upstream emulation core

PPSSPP remains the emulation engine. VANTA pins a known upstream tag so every APK can be reproduced and audited.

## Layer 2 — VANTA patch/overlay system

`scripts/apply_vanta.py` modifies only the Android-facing build identity and inserts VANTA-owned source files. The current bootstrap:

- changes the Android application ID to `com.vantapsp.emulator`;
- limits the normal flavor to ARM64;
- makes the optimized build non-JNI-debuggable;
- renames the visible Android app to VANTA PSP;
- redirects Android launcher startup to `VantaLauncherActivity`;
- retains PPSSPP's `PpssppActivity` as the emulation/core screen.

## Layer 3 — VANTA launcher

The launcher is a lightweight native Android Activity with no new UI dependency. It supports:

- Android Storage Access Framework game picker;
- persisted last-game URI;
- one-tap resume;
- direct entry to the PPSSPP core UI;
- gamepad A activation for focused controls;
- START shortcut to the core UI;
- landscape controller-first layout.

## Layer 4 — Device optimization (next milestones)

Runtime performance tuning should be evidence-driven, not a pile of universal hacks. VANTA will add telemetry hooks and per-game/device profiles before applying aggressive defaults.
