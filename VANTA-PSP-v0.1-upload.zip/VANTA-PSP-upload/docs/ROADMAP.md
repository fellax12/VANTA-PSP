# Roadmap

## M0 — Bootstrap

- [x] PPSSPP engine pin
- [x] reproducible GitHub Actions pipeline
- [x] ARM64 optimized build target
- [x] custom Android application ID
- [x] custom VANTA launcher
- [x] file picker + last-game resume
- [x] controller-focused launcher behavior
- [ ] first successful CI APK

## M1 — VANTA identity

- [x] custom adaptive icon
- [ ] custom Android TV banner
- [ ] Obsidian splash screen
- [ ] deeper PPSSPP menu theming
- [ ] VANTA typography and settings labels

## M2 — VANTA Boost

- [ ] collect frame-time / thermal observations on target phone
- [ ] Vulkan-first profile with safe OpenGL fallback
- [ ] per-game internal resolution profiles
- [ ] shader-cache controls
- [ ] frame pacing presets
- [ ] AutoTune profile selection
- [ ] HeatShield thermal policy

## M3 — Controller layer

- [ ] EasySMX X05 default profile
- [ ] controller diagnostics screen
- [ ] remapping presets
- [ ] xCloud-style navigation consistency tests

## M4 — Polish

- [ ] crash/log export
- [ ] backup/import settings
- [ ] per-game cover art library
- [ ] release signing and versioning
